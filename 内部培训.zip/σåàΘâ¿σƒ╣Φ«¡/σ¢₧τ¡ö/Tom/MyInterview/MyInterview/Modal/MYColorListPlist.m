//
//  MYColorListPlist.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColorListPlist.h"
#import "Util.h"
#import "MYColor.h"

#define kLocalFileNmae        @"save.plist"

@implementation MYColorListPlist

- (instancetype)init {
  
  self = [super init];
  
  if (!self) {
    return nil;
  }
  
  NSArray *array = [[NSArray alloc] initWithContentsOfFile:[Util fileName2docFilePath:kLocalFileNmae]];
  if (array) {
    
    for (int i=0; i<[array count];i++) {
      
      NSDictionary *dic = [array objectAtIndex:i];
      MYColor *color = [[MYColor alloc] initWithDictionary:dic];
      [self.rawData addObject:color];
    }
    
  }else {
    
    [self save];
  }

  return self;
}

- (void)save {
  
  [super save];
  
  NSMutableArray *array = [[NSMutableArray alloc] init];
  for (int i=0; i<[self.rawData count]; i++) {
    
    MYColor *color = [self.rawData objectAtIndex:i];
    NSDictionary *dic = [color dictionaryConversion];
    [array addObject:dic];
  }
  
  [array writeToFile:[Util fileName2docFilePath:kLocalFileNmae] atomically:YES];
}

- (MYSaveType)saveType {
  
  return MYSaveType_plist;
}


@end
