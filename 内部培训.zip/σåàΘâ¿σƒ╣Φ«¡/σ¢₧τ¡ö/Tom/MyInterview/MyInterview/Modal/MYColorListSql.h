//
//  MYColorListSqlite.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColorList.h"

@interface MYColorListSql : MYColorList

@end
