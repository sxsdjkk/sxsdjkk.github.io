//
//  Util.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define INT2NUM(x) [NSNumber numberWithInteger:(x)]
#define DOUBLE2NUM(x) [NSNumber numberWithDouble:(x)]
#define FLOAT2NUM(x) [NSNumber numberWithFloat:(x)]
#define INT2STR(x) [NSString stringWithFormat:@"%d", (x)]
#define LONGLONG2NUM(x) [NSNumber numberWithLongLong:(x)]
#define LONG2STR(x) [NSString stringWithFormat:@"%ld", (x)]
#define LONG2NUM(x) [NSNumber numberWithLong:(x)]
#define LONGLONG2STR(x) [NSString stringWithFormat:@"%lld", (x)]
#define SAFESTR(x) ((x)==nil)?@"":(x)

///// 矩形相关
#define CGRectTop(rect) rect.origin.y
#define CGRectLeft(rect) rect.origin.x
#define CGRectBottom(rect) (rect.size.height + rect.origin.y)
#define CGRectRight(rect) (rect.size.width + rect.origin.x)
#define CGRectSet(view, xx, yy, ww, hh) [view setFrame:CGRectMake((xx)==-1?view.frame.origin.x:(xx), (yy)==-1?view.frame.origin.y:(yy),(ww)==-1?view.frame.size.width:(ww), (hh)==-1?view.frame.size.height:(hh))]

@interface Util : NSObject

+ (NSString *)fileName2docFilePath:(NSString *)fileName;
+ (NSString *)filename2tmpFilePath:(NSString *)fileName;
+ (UITableViewCell *)cellByClassName:(NSString *)className inNib:(NSString *)nibName forTableView:(UITableView *)tableView;

@end
