//
//  MYColorList.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MYColor;

typedef enum MYSaveType_ {
  
  MYSaveType_archieve   = 1,
  MYSaveType_plist      = 2,
  MYSaveType_sql        = 3
  
} MYSaveType;

@interface MYColorList : NSObject

@property (nonatomic, strong) NSMutableArray *rawData;

/* 在末尾增加color，并排序 */
- (void)addColor:(MYColor *)color;

/* 删除某个color，并排序 */
- (void)removeColorAtIndex:(NSUInteger)index;

/* 替换某个颜色，并排序 */
- (void)replaceWithColor:(MYColor *)color atIndex:(NSUInteger)index;

/* 判断是否为空 */
- (BOOL)isEmpty;

/* 保存，子类需要改写 */
- (void)save;

/* 对应的保存类型，子类需要改写 */
- (MYSaveType)saveType;


- (NSInteger)count;
- (MYColor *)objectAtIndex:(NSUInteger)index;

@end
