//
//  MYColor.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MYColor : NSObject <NSCopying, NSCoding>

@property (nonatomic) float red;
@property (nonatomic) float green;
@property (nonatomic) float blue;
@property (nonatomic) NSInteger colorID;
@property (nonatomic, copy) NSString *colorName;
@property (nonatomic) NSTimeInterval modifyTimeInterval;

- (instancetype)initWithName:(NSString *)colorName red:(float)red green:(float)green blue:(float)blue colorID:(NSInteger)colorID;
- (instancetype)init;
- (instancetype)initWithDictionary:(NSDictionary *)dic;

- (void)save;
- (NSComparisonResult)compareToColor:(MYColor *)color;
- (NSDictionary *)dictionaryConversion;

- (UIColor *)uiColor;

@end
