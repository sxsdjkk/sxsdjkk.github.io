//
//  Util.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Util.h"

@implementation Util

+ (NSString *)fileName2docFilePath:(NSString *)fileName {
  
  if (!fileName || [fileName isEqualToString:@""]) {
    return nil;
  }
  
  NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  NSString *documentsDirectory = [paths objectAtIndex:0];
  NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
  return filePath;
}

+ (NSString *)filename2tmpFilePath:(NSString *)fileName {
  
  if (!fileName || [fileName isEqualToString:@""]) {
    return nil;
  }
  
  NSString *documentsDirectory = NSTemporaryDirectory();
  NSString *filePath = [documentsDirectory stringByAppendingPathComponent:fileName];
  return filePath;
}

+ (UITableViewCell *)cellByClassName:(NSString *)className inNib:(NSString *)nibName forTableView:(UITableView *)tableView {
  
  Class cellClass = NSClassFromString(className);
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:className];
  if (cell == nil) {
    
    NSArray *nib = [[NSBundle mainBundle] loadNibNamed:nibName owner:self options:nil];
    
    for (id oneObject in nib)
      if ([oneObject isMemberOfClass:cellClass])
        return oneObject;
  }
  return cell;
}

@end
