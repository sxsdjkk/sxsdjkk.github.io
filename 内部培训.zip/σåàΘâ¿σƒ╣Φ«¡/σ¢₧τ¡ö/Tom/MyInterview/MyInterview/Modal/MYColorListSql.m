//
//  MYColorListSqlite.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColorListSql.h"
#import "Util.h"
#import "sqlite3.h"
#import "MYColor.h"

#define kLocalFileName      @"main.sqlite"

@interface MYColorListSql ()

@property (nonatomic) sqlite3 *database;

@end

@implementation MYColorListSql

- (void)copyDbFile {
  
  // First, test for existence.
  BOOL success;
  NSError *error;
  NSString *writableDBPath = [Util fileName2docFilePath:kLocalFileName];
  success = [[NSFileManager defaultManager] fileExistsAtPath:writableDBPath];
  
  if (success) return;
  
  // The writable database does not exist, so copy the default to the appropriate location.
  NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:kLocalFileName];
  success = [[NSFileManager defaultManager] copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
  if (!success) {
    NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
  }
}


- (instancetype)init {
  
  self = [super init];
  
  if (self) {
    [self copyDbFile];
    [self openDatabaseByName:kLocalFileName];
    [self loadAllColors];
  }
  
  return self;
}

- (void)loadAllColors {
  
  [self.rawData removeAllObjects];
  NSString *selectString = @"SELECT * FROM colors ORDER BY modifyDate DESC";
  
  sqlite3_stmt *statement;
  int result = sqlite3_prepare_v2(_database, [selectString UTF8String], -1, &statement, nil);
  
  if (result == SQLITE_OK) {
    
    while (sqlite3_step(statement) == SQLITE_ROW) {
      
      NSMutableDictionary *objDic = [[NSMutableDictionary alloc] init];
      int columnCount = sqlite3_column_count(statement);
      for (int i = 0; i < columnCount; i++) {
        
        int columnType = sqlite3_column_type(statement, i);
        char *columnName = (char *) sqlite3_column_name(statement, i);
        NSString *columnNameStr = [[NSString alloc] initWithUTF8String:columnName];
        
        if (columnType == SQLITE_TEXT) {
          
          char *rowData = (char *) sqlite3_column_text(statement, i);
          
          if (!rowData) {
            
            [objDic setObject:@"" forKey:columnNameStr];
            
          } else {
            
            NSString *fieldValue = [[NSString alloc] initWithUTF8String:rowData];
            
            if (fieldValue)
              [objDic setObject:fieldValue forKey:columnNameStr];
            else
              [objDic setObject:@"" forKey:columnNameStr];
          }
          
        } else if (columnType == SQLITE_INTEGER) {
          
          long rowData = sqlite3_column_int(statement, i);
          [objDic setObject:[NSNumber numberWithLong:rowData] forKey:columnNameStr];
          
        } else if (columnType == SQLITE_FLOAT) {
          
          double rowData= sqlite3_column_double(statement, i);
          [objDic setObject:[NSNumber numberWithDouble:rowData] forKey:columnNameStr];
        }
      }

      MYColor *color = [[MYColor alloc] initWithDictionary:objDic];
      [self.rawData addObject:color];
    }
    sqlite3_finalize(statement);
    
  } else {
    
    sqlite3_finalize(statement);
    NSAssert1(0, @"查询语句错误在数据库中的表格colors, 错误代码: %d", result);
  }
}

- (void)addColor:(MYColor *)color {
  
  NSString *commandStr = @"INSERT INTO colors(colorName,red,green,blue,modifyDate) VALUES(?,?,?,?,?)";
  
  sqlite3_stmt *stmt;
  
  NSInteger sqlPrepareResult = sqlite3_prepare_v2(_database, [commandStr UTF8String], -1, &stmt, nil);
  
  if (sqlPrepareResult == SQLITE_OK) {
    
    NSUInteger stamentCount = 1;
    sqlite3_bind_text(stmt, (int)stamentCount++, [color.colorName UTF8String], -1, NULL);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.red);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.green);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.blue);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.modifyTimeInterval);
    NSInteger sql_result = sqlite3_step(stmt);
    
    if (sql_result != SQLITE_DONE) {
      
      NSAssert1(0, @"错误INSERT数据库中的表格colors, 错误代码: %@", @(sql_result));
    }
    sqlite3_finalize(stmt);
    
    color.colorID = sqlite3_last_insert_rowid(_database);
    
    [super addColor:color];
  }
  else {
    
    sqlite3_finalize(stmt);
    NSAssert1(0, @"错误准备INSERT数据库中的表格colors, 错误代码: %@", @(sqlPrepareResult));
  }
}

- (void)removeColorAtIndex:(NSUInteger)index {
  
  MYColor *color = [self.rawData objectAtIndex:index];
  NSString *commandString = [NSString stringWithFormat:@"DELETE FROM colors WHERE colorID = %ld",color.colorID];
  BOOL success = [self runCommandByFullSQL:commandString];
  if (success) {
    
    [super removeColorAtIndex:index];
  }
}

- (void)replaceWithColor:(MYColor *)color atIndex:(NSUInteger)index {
  
  NSString *commandString = [NSString stringWithFormat:@"UPDATE colors SET colorName=?,red=?,green=?,blue=?,modifyDate=? WHERE colorID=%ld", color.colorID];
  
  sqlite3_stmt *stmt;
  
  NSInteger sqlPrepareResult = sqlite3_prepare_v2(_database, [commandString UTF8String], -1, &stmt, nil);
  
  if (sqlPrepareResult == SQLITE_OK) {
    
    NSUInteger stamentCount = 1;
    sqlite3_bind_text(stmt, (int)stamentCount++, [color.colorName UTF8String], -1, NULL);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.red);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.green);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.blue);
    sqlite3_bind_double(stmt, (int)stamentCount++, color.modifyTimeInterval);
    NSInteger sql_result = sqlite3_step(stmt);
    
    if (sql_result != SQLITE_DONE) {
      
      NSAssert1(0, @"错误UPDATE数据库中的表格colors, 错误代码: %@", @(sql_result));
    }
    sqlite3_finalize(stmt);
    
    [super replaceWithColor:color atIndex:index];
  }
  else {
    
    sqlite3_finalize(stmt);
    NSAssert1(0, @"错误准备UPDATE数据库中的表格colors, 错误代码: %@", @(sqlPrepareResult));
  }

}

#pragma mark - Sqlite3
- (BOOL)openDatabaseByName:(NSString *)aName {
  
  NSString *databaseFileName = [Util fileName2docFilePath:aName];
  
  int result = sqlite3_open_v2([databaseFileName UTF8String], &_database, SQLITE_OPEN_READWRITE|SQLITE_OPEN_FULLMUTEX, nil);
  
  if (result == SQLITE_OK)
    return YES;
  else
    return NO;
}

- (BOOL)runCommandByFullSQL:(NSString *)commandStr {
  
  sqlite3_stmt *statement;
  
  int result = sqlite3_prepare_v2(_database, [commandStr UTF8String], -1, &statement, nil);
  
  if (result == SQLITE_OK) {
    
    result = sqlite3_step(statement);
    sqlite3_finalize(statement);
    
    if (result == SQLITE_DONE)
      return YES;
    else {
      NSAssert1(0, @"错误执行语句, 错误代码: %d", result);
      return NO;
    }
    
  } else {
    
    sqlite3_finalize(statement);
    NSAssert1(0, @"错误执行语句, 错误代码: %d", result);
    return NO;
  }
}

#pragma mark - 
- (void)save {
  [super save];
}

- (MYSaveType)saveType {
  
  return MYSaveType_sql;
}

@end
