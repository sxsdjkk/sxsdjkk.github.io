//
//  MYColorListArchieve.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColorListArchieve.h"
#import "Util.h"


#define kLocalFileNmae        @"save_arch"
#define kArchiveKey           @"array"

@implementation MYColorListArchieve

- (instancetype)init {
  
  self = [super init];
  
  if (!self) {
    return nil;
  }
  
  NSData *data = [[NSMutableData alloc] initWithContentsOfFile:[Util fileName2docFilePath:kLocalFileNmae]];
  
  if (data) {
    
    NSKeyedUnarchiver *un = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    NSMutableArray *array = [un decodeObjectForKey:kArchiveKey];
    [un finishDecoding];
    
    if (array) {
      self.rawData = array;
    }
    
  }
  
  return self;
}

- (void)save {
  
  [super save];
  
  NSMutableData *data = [[NSMutableData alloc] init];
  NSKeyedArchiver *ar = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
  [ar encodeObject:self.rawData forKey:kArchiveKey];
  [ar finishEncoding];
  [data writeToFile:[Util fileName2docFilePath:kLocalFileNmae] atomically:YES];
}

- (MYSaveType)saveType {
  
  return MYSaveType_archieve;
}


@end
