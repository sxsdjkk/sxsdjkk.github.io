//
//  MYColor.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColor.h"
#import "Util.h"

#pragma mark - Constants

#define kDefaultColorName @"我是颜色的名字"
#define kDefaultColorRed    0
#define kDefaultColorGreen  0
#define kDefaultColorBlue   0
#define kDefaultColorID     0

#pragma mark - NSCoding Key

#define kID         @"colorID"
#define kName       @"colorName"
#define kModifyDate @"modifyDate"
#define kRed      @"red"
#define kGreen    @"green"
#define kBlue     @"blue"
#define kClass    @"MYColor"

#pragma mark -

@implementation MYColor

- (instancetype)initWithName:(NSString *)colorName red:(float)red green:(float)green blue:(float)blue colorID:(NSInteger)colorID{
  
  self = [super init];
  if (self) {
    
    _red = red;
    _green = green;
    _blue = blue;
    
    _colorID = colorID;
    _colorName = [colorName copy];
    
    _modifyTimeInterval = [[NSDate date] timeIntervalSinceReferenceDate];
  }
  
  return self;
}

- (instancetype)init {
  
  self = [self initWithName:kDefaultColorName
                        red:kDefaultColorRed
                      green:kDefaultColorGreen
                       blue:kDefaultColorBlue
                    colorID:kDefaultColorID];
  if (self) {
    
  }
  
  return self;
}

- (instancetype)initWithDictionary:(NSDictionary *)dic {
  
  self = [self init];
  if (self) {
    _red = [[dic objectForKey:kRed] floatValue];
    _green = [[dic objectForKey:kGreen] floatValue];
    _blue = [[dic objectForKey:kBlue] floatValue];
    _colorID = [[dic objectForKey:kID] integerValue];
    _colorName = [[dic objectForKey:kName] copy];
    _modifyTimeInterval = [[dic objectForKey:kModifyDate] doubleValue];
  }
  
  return self;
}

- (void)dealloc {
  
}

#pragma mark - NSCoding, NSCopying
- (void)encodeWithCoder:(NSCoder *)aCoder {
  
  [aCoder encodeFloat:_red forKey:kRed];
  [aCoder encodeFloat:_green forKey:kGreen];
  [aCoder encodeFloat:_blue forKey:kBlue];
  [aCoder encodeInteger:_colorID forKey:kID];
  [aCoder encodeObject:_colorName forKey:kName];
  [aCoder encodeDouble:_modifyTimeInterval forKey:kModifyDate];
}

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder {
  
  self = [super init];
  
  if (self) {
    
    _red = [aDecoder decodeFloatForKey:kRed];
    _green = [aDecoder decodeFloatForKey:kGreen];
    _blue = [aDecoder decodeFloatForKey:kBlue];
    _colorID = [aDecoder decodeIntegerForKey:kID];
    _colorName = [[aDecoder decodeObjectForKey:kName] copy];
    _modifyTimeInterval = [aDecoder decodeDoubleForKey:kModifyDate];
  }
  
  return self;
}

- (instancetype)copyWithZone:(NSZone *)zone {
  
  MYColor *copy = [[[self class] allocWithZone:zone] init];
  
  copy.colorName = [_colorName copyWithZone:zone];
  copy.red = _red;
  copy.green = _green;
  copy.blue = _blue;
  copy.colorID = _colorID;
  copy.modifyTimeInterval = _modifyTimeInterval;
  
  return copy;
}

#pragma mark - Public

- (void)save {
  
  _modifyTimeInterval = [[NSDate date] timeIntervalSinceReferenceDate];
}

- (NSComparisonResult)compareToColor:(MYColor *)color {
  
  if (self.modifyTimeInterval < color.modifyTimeInterval) {
    return NSOrderedDescending;
  }
  
  if (self.modifyTimeInterval > color.modifyTimeInterval){
    return NSOrderedAscending;
  }
  
  return NSOrderedSame;
}

- (NSDictionary *)dictionaryConversion {
  
  return [NSDictionary dictionaryWithObjectsAndKeys:
          FLOAT2NUM(_red),kRed,
          FLOAT2NUM(_green),kGreen,
          FLOAT2NUM(_blue),kBlue,
          _colorName,kName,
          INT2NUM(_colorID),kID,
          DOUBLE2NUM(_modifyTimeInterval),kModifyDate,
          nil];
}

- (UIColor *)uiColor {
  
  return [UIColor colorWithRed:self.red/255.0 green:self.green/255.0 blue:self.blue/255.0 alpha:1.0];
}
@end
