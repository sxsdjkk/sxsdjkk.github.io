//
//  MYColorList.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColorList.h"
#import "MYColor.h"

@implementation MYColorList

#pragma mark - Init
- (instancetype)init {
  
  self = [super init];
  if (self) {
    _rawData = [[NSMutableArray alloc] init];
  }
  return self;
}

#pragma mark - Private
- (void)sortColor {
  
  [_rawData sortUsingComparator:^NSComparisonResult(MYColor *c1, MYColor *c2) {
    return [c1 compareToColor:c2];
  }];
}

#pragma mark - Virtual
- (void)save {
  
  NSAssert([[self class] isSubclassOfClass:[MYColorList class]], @"调用错误，必须在子类中调用");
}

- (MYSaveType)saveType {
  
  NSAssert([[self class] isSubclassOfClass:[MYColorList class]], @"调用错误，必须在子类中调用");
  return 0;
}

#pragma mark - Public
/* 在末尾增加color，并排序 */
- (void)addColor:(MYColor *)color {
  
  
  [_rawData addObject:color];
  [self sortColor];
  [self save];
}

/* 删除某个color，并排序 */
- (void)removeColorAtIndex:(NSUInteger)index {
  
  [_rawData removeObjectAtIndex:index];
  [self sortColor];
  [self save];
}

/* 替换某个颜色 */
- (void)replaceWithColor:(MYColor *)color atIndex:(NSUInteger)index {
  
  [_rawData replaceObjectAtIndex:index withObject:color];
  [self sortColor];
  [self save];
}

- (BOOL)isEmpty {

  if (_rawData == nil) {
    return YES;
  }
  
  return !([_rawData count] > 0) ;
}

- (NSInteger)count {
  
  return [_rawData count];
}

- (MYColor *)objectAtIndex:(NSUInteger)index {
  
  return [_rawData objectAtIndex:index];
}
@end
