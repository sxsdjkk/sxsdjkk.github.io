//
//  MYListVCTL.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MYColorList.h"

@interface MYListVCTL : UIViewController

@property (nonatomic) MYSaveType saveType;

- (instancetype)initWithSaveType:(MYSaveType)saveType;

@end
