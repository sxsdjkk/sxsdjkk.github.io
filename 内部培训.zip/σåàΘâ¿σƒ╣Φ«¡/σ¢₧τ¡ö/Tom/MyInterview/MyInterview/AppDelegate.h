//
//  AppDelegate.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

