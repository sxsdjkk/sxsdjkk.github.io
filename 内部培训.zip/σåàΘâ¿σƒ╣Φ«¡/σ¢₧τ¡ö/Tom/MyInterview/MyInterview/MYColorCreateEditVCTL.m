//
//  MYColorCreateEditVCTL.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColorCreateEditVCTL.h"
#import "MYListVCTL.h"
#import "Util.h"

@interface MYColorCreateEditVCTL ()

@property (nonatomic, strong) MYColor *tempColor;

@end

@implementation MYColorCreateEditVCTL

- (void)viewDidLoad {
  
  [super viewDidLoad];
  if (_originalColor) {
    _tempColor = [_originalColor copy];
    self.navigationItem.title = @"编辑颜色";
  }else {
    _tempColor = [[MYColor alloc] init];
    self.navigationItem.title = @"创建颜色";
  }
  
  UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(save:)];
  self.navigationItem.rightBarButtonItem = item;
  
  [self updateColorValues:YES];
}

- (void)viewWillAppear:(BOOL)animated {
  
  [super viewWillAppear:animated];
  [self relayoutViews];
}

- (void)relayoutViews {
  
  CGFloat screenHeight = [UIScreen mainScreen].bounds.size.height;
  CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
  
  CGRectSet(self.ibColorView, 0,44.0f, screenWidth,screenWidth);
  CGRectSet(self.ibNameField, -1, -1, screenWidth-2*self.ibNameField.frame.origin.x, -1);
  CGFloat start_Y = CGRectBottom(self.ibColorView.frame);
  CGFloat padding = (screenHeight - start_Y - 3*self.ibHoldingView1.frame.size.height) /4.0;
  CGRectSet(self.ibHoldingView1, -1, start_Y+padding, -1, -1);
  CGRectSet(self.ibHoldingView2, -1, CGRectBottom(self.ibHoldingView1.frame)+padding, -1, -1);
  CGRectSet(self.ibHoldingView3, -1, CGRectBottom(self.ibHoldingView2.frame)+padding, -1, -1);
}

- (void)updateColorValues:(BOOL)changeSliders {
  
  if (changeSliders) {
    _ibRedSlider.value = _tempColor.red;
    _ibGreenSlider.value = _tempColor.green;
    _ibBlueSlider.value = _tempColor.blue;
  }
  
  self.ibColorView.backgroundColor = [_tempColor uiColor];
  
  self.ibNameField.text = _tempColor.colorName;
  
  self.ibRed.text = [NSString stringWithFormat:@"%.0f",_tempColor.red];
  
  self.ibGreen.text = [NSString stringWithFormat:@"%.0f",_tempColor.green];
  
  self.ibBlue.text = [NSString stringWithFormat:@"%.0f",_tempColor.blue];
}

- (IBAction)valueChaged:(id)sender {

  _tempColor.colorName = _ibNameField.text;
  [_ibNameField resignFirstResponder];
  
  UISlider *s = (UISlider *)sender;
  if (s.tag == 1) {
    _tempColor.red = s.value;
  }

  if (s.tag == 2) {
    _tempColor.green = s.value;
  }

  if (s.tag == 3) {
    _tempColor.blue = s.value;
  }
  
  [self updateColorValues:NO];
}

- (IBAction)textFieldEditEnd:(id)sender {
  
  _tempColor.colorName = _ibNameField.text;
}

- (IBAction)textFieldDidEndOnExit:(id)sender {
  
  _tempColor.colorName = _ibNameField.text;
}

- (void)save:(id)sender {
  
  [_ibNameField resignFirstResponder];
  [_tempColor save];
  
  if (_originalColor) {
    // 编辑模式
    [_colorList replaceWithColor:_tempColor atIndex:_colorListIndex];
  }else {
    // 创建模式
    [_colorList addColor:_tempColor];
  }
  
  BOOL justPop = NO;
  for(UIViewController *vctl in [self.navigationController viewControllers]){
    if ([vctl isKindOfClass:[MYListVCTL class]]) {
      justPop = YES;
      break;
    }
  }
  if (justPop) {
    [self.navigationController popViewControllerAnimated:YES];
    
  }else {
    __strong UINavigationController *navi = self.navigationController;
    [self.navigationController popViewControllerAnimated:NO];
    MYSaveType saveType = [_colorList saveType];
    MYListVCTL *vctl = [[MYListVCTL alloc] initWithSaveType:saveType];
    [navi pushViewController:vctl animated:NO];
  }
}
@end
