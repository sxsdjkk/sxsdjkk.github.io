//
//  MYListVCTL.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYListVCTL.h"
#import "MYColorListArchieve.h"
#import "MYColorListPlist.h"
#import "MYColorListSql.h"
#import "MYColorTableViewCell.h"
#import "Util.h"
#import "MYColorCreateEditVCTL.h"

@interface MYListVCTL ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) MYColorList *colorList;


@end

@implementation MYListVCTL

- (instancetype)initWithSaveType:(MYSaveType)saveType {
  
  self = [super init];
  if (self) {
    _saveType = saveType;
  }
  return self;
}

- (void)viewDidLoad {
  
  [super viewDidLoad];
  
  self.navigationItem.title = @"颜色列表";
  UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"创建" style:UIBarButtonItemStylePlain target:self action:@selector(create:)];
  self.navigationItem.rightBarButtonItem = item;

  _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
  _tableView.delegate = self;
  _tableView.dataSource = self;
  [self.view addSubview:_tableView];
  
  if (_saveType == MYSaveType_archieve) {
    
    _colorList = [[MYColorListArchieve alloc] init];
  }
  
  if (_saveType == MYSaveType_plist) {
    _colorList = [[MYColorListPlist alloc] init];
  }
  
  if (_saveType == MYSaveType_sql) {
    _colorList = [[MYColorListSql alloc] init];
  }
}

- (void)viewWillAppear:(BOOL)animated {
  
  [super viewWillAppear:animated];
  if ([_colorList isEmpty]) {
    
    __strong UINavigationController *navi = self.navigationController;
    [self.navigationController popViewControllerAnimated:NO];
    
    MYColorCreateEditVCTL *vctl = [[MYColorCreateEditVCTL alloc] init];
    vctl.originalColor = nil;
    vctl.colorList = _colorList;
    vctl.colorListIndex = -1;
    [navi pushViewController:vctl animated:NO];
    return;
  }
  
  [_tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  // Return the number of sections.
  return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  // Return the number of rows in the section.
  return [_colorList count];
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  
  
  NSInteger row = indexPath.row;
  MYColorTableViewCell *cell = (MYColorTableViewCell*)[Util cellByClassName:@"MYColorTableViewCell" inNib:@"MYTableViewCell" forTableView:_tableView];
  [cell setCellWithColor:[_colorList objectAtIndex:row]];
  return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
  
  return [MYColorTableViewCell cellHeight];
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
  
  return YES;
}


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {

  if (editingStyle == UITableViewCellEditingStyleDelete) {
    
    // Delete the row from the data source
    
    [_colorList removeColorAtIndex:[indexPath row]];
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
  }
  else if (editingStyle == UITableViewCellEditingStyleInsert) {
  // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
  }
}

#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

  NSInteger index = [indexPath row];
  
  MYColorCreateEditVCTL *vctl = [[MYColorCreateEditVCTL alloc] init];
  vctl.originalColor = [_colorList objectAtIndex:index];
  vctl.colorList = _colorList;
  vctl.colorListIndex = index;
  [self.navigationController pushViewController:vctl animated:YES];
}

#pragma mark - 
- (void)create:(id)sender {
  
  MYColorCreateEditVCTL *vctl = [[MYColorCreateEditVCTL alloc] init];
  vctl.originalColor = nil;
  vctl.colorList = _colorList;
  vctl.colorListIndex = -1;
  [self.navigationController pushViewController:vctl animated:YES];
}
@end
