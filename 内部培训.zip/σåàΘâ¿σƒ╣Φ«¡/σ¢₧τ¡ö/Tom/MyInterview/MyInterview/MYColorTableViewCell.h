//
//  MYColorTableViewCell.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MYColor.h"

@interface MYColorTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIView *ibColorView;
@property (strong, nonatomic) IBOutlet UILabel *ibRedLbl;
@property (strong, nonatomic) IBOutlet UILabel *ibNameLbl;
@property (strong, nonatomic) IBOutlet UILabel *ibBlueLbl;
@property (strong, nonatomic) IBOutlet UILabel *ibGreenLbl;

- (void)setCellWithColor:(MYColor *)color;
+ (float)cellHeight;
@end
