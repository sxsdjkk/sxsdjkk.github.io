//
//  ViewController.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYViewController.h"
#import "MYListVCTL.h"
#import "Util.h"

@interface MYViewController ()

@end

@implementation MYViewController

- (void)viewDidLoad {
  
  [super viewDidLoad];
  // Do any additional setup after loading the view, typically from a nib.
}

- (void)viewWillAppear:(BOOL)animated {

  [super viewWillAppear:animated];
  [self.navigationController.navigationBar setHidden:YES];
  [self relayoutButtons];
}

- (void)viewWillDisappear:(BOOL)animated {
  
  [super viewWillDisappear:animated];
  [self.navigationController.navigationBar setHidden:NO];
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
  // Dispose of any resources that can be recreated.
}


#pragma mark - Private

- (void)relayoutButtons {
  
  CGFloat viewHeight = self.view.frame.size.height;
  CGFloat buttonHeight = self.ibButton1.frame.size.height;
  CGFloat start_y = MAX((1.0/4.0*viewHeight),CGRectBottom(self.ibNameLbl.frame)+40);
  CGFloat padding = (viewHeight-start_y-3.0*buttonHeight)/4.0;
  
  CGRectSet(self.ibButton1,-1,start_y+padding,-1,-1);
  CGRectSet(self.ibButton2,-1,CGRectBottom(self.ibButton1.frame)+padding, -1, -1);
  CGRectSet(self.ibButton3,-1,CGRectBottom(self.ibButton2.frame)+padding, -1, -1);
}


#pragma mark - Public

- (IBAction)onButton:(id)sender {
  
  UIButton *button = (UIButton *)sender;
  MYListVCTL *vctl = [[MYListVCTL alloc] initWithSaveType:(MYSaveType)button.tag];
  [self.navigationController pushViewController:vctl animated:YES];
}
@end
