//
//  ViewController.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MYViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *ibButton1;
@property (strong, nonatomic) IBOutlet UIButton *ibButton2;
@property (strong, nonatomic) IBOutlet UIButton *ibButton3;
@property (strong, nonatomic) IBOutlet UILabel *ibNameLbl;


- (IBAction)onButton:(id)sender;

@end

