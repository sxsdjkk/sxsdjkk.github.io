//
//  MYColorCreateEditVCTL.h
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MYColor.h"
#import "MYColorList.h"

@interface MYColorCreateEditVCTL : UIViewController

@property (strong, nonatomic) IBOutlet UIView *ibColorView;
@property (strong, nonatomic) IBOutlet UITextField *ibNameField;
@property (strong, nonatomic) IBOutlet UILabel *ibRed;
@property (strong, nonatomic) IBOutlet UILabel *ibGreen;
@property (strong, nonatomic) IBOutlet UILabel *ibBlue;
@property (strong, nonatomic) IBOutlet UISlider *ibRedSlider;
@property (strong, nonatomic) IBOutlet UISlider *ibGreenSlider;
@property (strong, nonatomic) IBOutlet UISlider *ibBlueSlider;
@property (strong, nonatomic) IBOutlet UIView *ibHoldingView1;
@property (strong, nonatomic) IBOutlet UIView *ibHoldingView2;
@property (strong, nonatomic) IBOutlet UIView *ibHoldingView3;


@property (nonatomic, strong) MYColor *originalColor;
@property (nonatomic, strong) MYColorList *colorList;
@property (nonatomic) NSInteger    colorListIndex;

- (IBAction)valueChaged:(id)sender;
- (IBAction)textFieldEditEnd:(id)sender;
- (IBAction)textFieldDidEndOnExit:(id)sender;

@end
