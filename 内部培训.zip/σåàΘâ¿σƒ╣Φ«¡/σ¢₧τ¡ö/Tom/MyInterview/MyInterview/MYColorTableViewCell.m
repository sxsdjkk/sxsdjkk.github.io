//
//  MYColorTableViewCell.m
//  MyInterview
//
//  Created by Tom on 9/18/15.
//  Copyright © 2015 Ruoogle. All rights reserved.
//

#import "MYColorTableViewCell.h"

@implementation MYColorTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setCellWithColor:(MYColor *)color {
  
  self.ibColorView.backgroundColor = [color uiColor];
  self.ibNameLbl.text = color.colorName;
  self.ibRedLbl.text = [NSString stringWithFormat:@"R: %.0f",color.red];
  self.ibGreenLbl.text = [NSString stringWithFormat:@"G: %.0f",color.green];
  self.ibBlueLbl.text = [NSString stringWithFormat:@"B: %.0f", color.blue];
}

+ (float)cellHeight {
  
  return 166.0f;
}
@end
