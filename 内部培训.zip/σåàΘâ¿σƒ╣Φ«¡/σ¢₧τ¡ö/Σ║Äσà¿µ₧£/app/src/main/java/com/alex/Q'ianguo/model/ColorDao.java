package com.alex.training.model;

import android.content.Context;

import com.alex.training.FileUtil;
import com.alex.training.constant.SaveType;

import java.util.ArrayList;
import java.util.HashSet;

public class ColorDao {

    static ArrayList<Color> fileColors;
    static ArrayList<Color> localColors;

    public static int saveColor(final Context context, final int save_type, final Color color) {
        int result = 0;

        switch (save_type) {
            case SaveType.Local:
                if (localColors == null) {
                    localColors = new ArrayList<>();
                    localColors.add(color);
                    color.set_id(0);
                } else {
                    int size = localColors.size();
                    boolean isexister = false;
                    for (int i = 0; i < size; i++) {
                        Color c = localColors.get(i);
                        if (c.get_id() == color.get_id()) {
                            color.set_id(i);
                            localColors.remove(i);
                            localColors.add(i, color);
                            isexister = true;
                        }
                    }
                    if (!isexister) {
                        color.set_id(localColors.size());
                        localColors.add(color);
                    }
                }
                Store.saveObject(context, Store.Color_List, localColors);
                break;
            case SaveType.File:
                if (fileColors == null) {
                    fileColors = new ArrayList<>();
                    fileColors.add(color);
                    color.set_id(0);
                    ArrayList<String> strings = new ArrayList<>();
                    strings.add(color.getColorString());
                    FileUtil.writFile(context, "color.txt", strings);
                } else {
                    ArrayList<String> strings = new ArrayList<>();
                    int size = fileColors.size();
                    boolean isexister = false;
                    for (int i = 0; i < size; i++) {
                        Color c = fileColors.get(i);
                        if (c.get_id() == color.get_id()) {
                            color.set_id(i);
                            strings.add(color.getColorString());
                            fileColors.remove(i);
                            fileColors.add(i, color);
                            isexister = true;
                        } else {
                            strings.add(c.getColorString());
                        }
                    }
                    if (!isexister) {
                        color.set_id(fileColors.size());
                        fileColors.add(color);
                        strings.add(color.getColorString());
                    }
                    FileUtil.writFile(context, "color.txt", strings);
                }
                break;
            case SaveType.Sqlite:
                ColorDBHelper.insertColor(color);
                break;
            default:

        }

        return result;
    }

    public static int deleteColor(final Context context, final int save_type, final Color color) {
        int result = 0;

        switch (save_type) {
            case SaveType.Local:
                if (localColors != null) {
                    int size = localColors.size();
                    for (int i = 0; i < size; i++) {
                        Color c = localColors.get(i);
                        if (c.get_id() == color.get_id()) {
                            localColors.remove(i);
                            break;
                        }
                    }
                    Store.saveObject(context, Store.Color_List, localColors);
                }
                break;
            case SaveType.File:
                if (fileColors != null) {
                    ArrayList<String> strings = new ArrayList<>();
                    int size = fileColors.size();
                    for (int i = 0; i < size; i++) {
                        Color c = fileColors.get(i);
                        if (c.get_id() == color.get_id()) {
                            fileColors.remove(i);
                        } else {
                            strings.add(c.getColorString());
                        }
                    }
                    FileUtil.writFile(context, "color.txt", strings);
                }
                break;
            case SaveType.Sqlite:
                ColorDBHelper.deleteColor(color);
                break;
            default:

        }

        return result;
    }

    public static ArrayList<Color> getColors(Context context, final int save_type) {
        ArrayList<Color> colors = new ArrayList<>();
        switch (save_type) {
            case SaveType.Local:
                if (localColors == null) {
                    localColors = Store.getObject(context, Store.Color_List);
                }
                if (localColors != null) {
                    colors.addAll(localColors);
                }
                break;
            case SaveType.File:
                if (fileColors == null) {
                    ArrayList<String> strs = FileUtil.readFile(context, "color.txt");
                    for (String str : strs) {
                        Color color = Color.stringToColor(str);
                        if (color != null) {
                            colors.add(color);
                        }
                    }
                    fileColors = new ArrayList<>();
                    fileColors.addAll(colors);
                } else {
                    colors = fileColors;
                }
                break;
            case SaveType.Sqlite:
                colors.addAll(ColorDBHelper.queryColors());
                break;
            default:

        }
        return colors;
    }
}
