package com.alex.training.constant;

public interface ExtraName {

    String Need_Edit_Color = "Need_Edit_Color";
    String Save_Type = "Save_Type";
    String Color_List = "Color_List";
}
