package com.alex.training.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashSet;

public class Store {

    public static final String Color_List = "Color_List";

    private static final String PACK_NAME = Store.class.getPackage().getName();

    private Store() {
    }

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(
                PACK_NAME, Context.MODE_PRIVATE);
    }


    public static synchronized boolean saveObject(Context context, String key, Object obj) {

        if (obj == null)
            return false;
        SharedPreferences sharedPreferences = getSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        ObjectOutputStream oos = null;
        ByteArrayOutputStream baos = null;
        try {
            baos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(baos);
            oos.writeObject(obj);
            String oAuth_Base64 = new String(Base64.encode(baos.toByteArray(), Base64.DEFAULT));
            editor.putString(key, oAuth_Base64);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (baos != null) {
                    baos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return editor.commit();
    }

    // 获取对象类型
    public static <T> T getObject(Context context, String key) {
        SharedPreferences preferences = getSharedPreferences(context);
        ObjectInputStream ois = null;
        ByteArrayInputStream bais = null;
        T result = null;
        try {
            String str64 = preferences.getString(key, "");
            byte[] base64 = Base64.decode(str64.getBytes(), Base64.DEFAULT);
            bais = new ByteArrayInputStream(base64);
            ois = new ObjectInputStream(bais);
            result = (T) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (bais != null) {
                    bais.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return result;
    }

    public static void remove(Context context, String key) {
        SharedPreferences preferences = getSharedPreferences(context);
        SharedPreferences.Editor editor = preferences.edit();
        editor.remove(key);
        editor.apply();
    }

}