package com.alex.training;

import android.app.Activity;
import android.content.Context;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class FileUtil {

    public static ArrayList<String> readFile(Context context, String fileName) {
        ArrayList<String> list = new ArrayList<>();
        FileInputStream inputStream = null;
        DataInputStream dis = null;

        try {
            inputStream = context.openFileInput(fileName);
            dis = new DataInputStream(inputStream);
            String strLine;
            while ((strLine = dis.readLine()) != null) {
                list.add(strLine);
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dis != null) {
                    dis.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    public static void writFile(Context context, String fileName, ArrayList<String> strs) {
        if (strs == null || strs.size() <= 0) {
            return;
        }
        DataOutputStream dos = null;
        FileOutputStream outputStream = null;
        try {
            outputStream = context.openFileOutput(fileName,
                    Activity.MODE_PRIVATE);
            dos = new DataOutputStream(outputStream);

            for (String str : strs) {
                dos.write(str.getBytes());
                dos.write("\n".getBytes());
            }
            dos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (dos != null) {
                    dos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
