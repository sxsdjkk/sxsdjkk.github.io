package com.alex.training.activity;

import android.os.Bundle;
import android.view.View;

import com.alex.training.R;
import com.alex.training.activity.base.BaseActivity;
import com.alex.training.constant.SaveType;
import com.alex.training.model.Color;
import com.alex.training.model.ColorDao;

import java.util.ArrayList;

public class MainAct extends BaseActivity implements View.OnClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.tv_local).setOnClickListener(this);
        findViewById(R.id.tv_file).setOnClickListener(this);
        findViewById(R.id.tv_sqlite).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        int save_type = 0;
        switch (v.getId()) {

            case R.id.tv_local:
                save_type = SaveType.Local;
                break;
            case R.id.tv_file:
                save_type = SaveType.File;
                break;
            case R.id.tv_sqlite:
                save_type = SaveType.Sqlite;
                break;
            default:
        }
        ArrayList<Color> colors = ColorDao.getColors(mContext, save_type);
        if (colors.size() > 0) {
            ColorListAct.startColorListAct(mContext, colors, save_type);
        } else {
            CreateColorAct.startCreateColorAct(mContext, null, save_type);
        }
    }
}
