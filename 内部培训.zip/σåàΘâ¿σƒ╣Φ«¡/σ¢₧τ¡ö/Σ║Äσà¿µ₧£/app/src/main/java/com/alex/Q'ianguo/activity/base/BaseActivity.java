package com.alex.training.activity.base;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;

public class BaseActivity extends Activity {
    protected Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
    }

    protected void setText(int viewId, int resId) {
        String text = getStringSafe(resId);
        TextView tv = (TextView) findViewById(viewId);
        if (tv != null) {
            tv.setText(text);
        }
    }

    public String getStringSafe(int resid) {
        String result = "资源ID错误";
        try {
            result = super.getString(resid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
