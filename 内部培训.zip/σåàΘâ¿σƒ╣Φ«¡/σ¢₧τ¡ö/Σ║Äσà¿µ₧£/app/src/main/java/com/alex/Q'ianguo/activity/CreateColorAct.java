package com.alex.training.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.alex.training.R;
import com.alex.training.activity.base.BaseActivity;
import com.alex.training.constant.ExtraName;
import com.alex.training.model.Color;
import com.alex.training.model.ColorDao;

public class CreateColorAct extends BaseActivity {

    private int save_type;

    /**
     * 十六进制的三原色
     */
    private int r;
    private int g;
    private int b;

    private EditText et_color_name;
    private View view_color_show;
    private TextView tv_color_r_value;
    private TextView tv_color_g_value;
    private TextView tv_color_b_value;
    private com.alex.training.model.Color needEidtColor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_color);

        Intent i = getIntent();
        needEidtColor =
                (com.alex.training.model.Color) i.getSerializableExtra(ExtraName.Need_Edit_Color);
        save_type = i.getIntExtra(ExtraName.Save_Type, 0);
        if (needEidtColor != null) {
            r = needEidtColor.getR();
            g = needEidtColor.getG();
            b = needEidtColor.getB();
        }

        initViews();
    }

    public static void startCreateColorAct(Context context, Color color, int save_type) {
        Intent intent = new Intent(context, CreateColorAct.class);
        intent.putExtra(ExtraName.Save_Type, save_type);
        intent.putExtra(ExtraName.Need_Edit_Color, color);
        context.startActivity(intent);
    }

    private void initViews() {
        et_color_name = (EditText) findViewById(R.id.et_color_name);
        view_color_show = findViewById(R.id.view_color_show);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenWidth = dm.widthPixels;
        LayoutParams params = view_color_show.getLayoutParams();
        params.height = screenWidth;
        view_color_show.setLayoutParams(params);


        SeekBar sb_r = (SeekBar) findViewById(R.id.sb_r);
        SeekBar sb_g = (SeekBar) findViewById(R.id.sb_g);
        SeekBar sb_b = (SeekBar) findViewById(R.id.sb_b);

        tv_color_r_value = (TextView) findViewById(R.id.tv_color_r_value);
        tv_color_g_value = (TextView) findViewById(R.id.tv_color_g_value);
        tv_color_b_value = (TextView) findViewById(R.id.tv_color_b_value);

        sb_r.setOnSeekBarChangeListener(sbChangeListener);
        sb_g.setOnSeekBarChangeListener(sbChangeListener);
        sb_b.setOnSeekBarChangeListener(sbChangeListener);
        if (needEidtColor != null) {
            setText(R.id.action_bar_title, R.string.edit_color);
            view_color_show.setBackgroundColor(needEidtColor.getColor());
            et_color_name.setText(needEidtColor.getName());
            sb_r.setProgress(r);
            sb_g.setProgress(g);
            sb_b.setProgress(b);
            tv_color_r_value.setText(r + "");
            tv_color_g_value.setText(g + "");
            tv_color_b_value.setText(b + "");
        } else {
            setText(R.id.action_bar_title, R.string.create_color_title);
        }
        setText(R.id.action_bar_rightBtn, R.string.create_color_topright_btn);
        findViewById(R.id.action_bar_rightBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = et_color_name.getText().toString();
                if (TextUtils.isEmpty(name)) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext);  //先得到构造器
                    builder.setMessage("颜色名不能为空?"); //设置内容
                    builder.show();
                    return;
                }

                if (needEidtColor == null) {
                    needEidtColor = new Color();
                }
                needEidtColor.setName(name);
                needEidtColor.setR(r);
                needEidtColor.setG(g);
                needEidtColor.setB(b);
                needEidtColor.setLast_edit_stamp(System.currentTimeMillis());

                ColorDao.saveColor(mContext, save_type, needEidtColor);
                Toast.makeText(mContext, "保存成功", Toast.LENGTH_LONG).show();
            }
        });
    }

    private SeekBar.OnSeekBarChangeListener sbChangeListener = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            switch (seekBar.getId()) {
                case R.id.sb_r:
                    r = progress;
                    tv_color_r_value.setText(String.valueOf(progress));
                    break;
                case R.id.sb_g:
                    g = progress;
                    tv_color_g_value.setText(String.valueOf(progress));
                    break;
                case R.id.sb_b:
                    b = progress;
                    tv_color_b_value.setText(String.valueOf(progress));
                    break;
                default:
            }

            view_color_show.setBackgroundColor(android.graphics.Color.rgb(r, g, b));
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {

        }
    };

}
