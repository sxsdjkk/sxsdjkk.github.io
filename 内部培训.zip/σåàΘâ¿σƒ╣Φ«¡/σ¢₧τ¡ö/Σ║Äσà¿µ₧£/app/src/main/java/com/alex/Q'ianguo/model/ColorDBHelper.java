package com.alex.training.model;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class ColorDBHelper {

    private static final String TABLE_NAME = "color";

    public static long insertColor(Color color) {
        if (color == null) {
            return 0;
        }
        long result;
        ContentValues cv = beanToCv(color);
        if (color.get_id() > 0) {
            result = DatabaseUtil.update(TABLE_NAME, cv, ColorColumns.RECORD_ID + "=?", new String[]{color.get_id() + ""});
        } else {
            result = DatabaseUtil.insert(TABLE_NAME, cv);
        }
        return result;
    }

    public static ArrayList<Color> queryColors() {
        ArrayList<Color> list = new ArrayList<>();
        Cursor cursor = DatabaseUtil.query(TABLE_NAME, CONTENT_PROJECTION, null, null, null, null);
        if (cursor != null) {
            cursor.moveToPosition(-1);
            while (cursor.moveToNext()) {
                Color color = new Color();
                color.set_id(cursor.getInt(cursor.getColumnIndex(ColorColumns.RECORD_ID)));
                color.setName(cursor.getString(cursor.getColumnIndex(ColorColumns.NAME)));
                color.setR(cursor.getInt(cursor.getColumnIndex(ColorColumns.R)));
                color.setG(cursor.getInt(cursor.getColumnIndex(ColorColumns.G)));
                color.setB(cursor.getInt(cursor.getColumnIndex(ColorColumns.B)));
                color.setLast_edit_stamp(cursor.getLong(cursor.getColumnIndex(ColorColumns.LAST_EDIT_STAMP)));
                list.add(color);
            }


        }
        return list;
    }

    public static long deleteColor(Color color) {
        if (color == null) {
            return 0;
        }
        return DatabaseUtil.delete(TABLE_NAME, ColorColumns.RECORD_ID + "=?", new String[]{color.get_id() + ""});
    }


    private static ContentValues beanToCv(Color color) {
        ContentValues cv = new ContentValues();
        cv.put(ColorColumns.NAME, color.getName());
        cv.put(ColorColumns.R, color.getR());
        cv.put(ColorColumns.G, color.getG());
        cv.put(ColorColumns.B, color.getB());
        cv.put(ColorColumns.LAST_EDIT_STAMP, color.getLast_edit_stamp());
        return cv;
    }

    public interface ColorColumns {

        String RECORD_ID = "_id";

        String NAME = "name";
        String R = "r";
        String G = "g";
        String B = "b";
        String LAST_EDIT_STAMP = "last_edit_stamp";

    }

    public static final String[] CONTENT_PROJECTION = new String[]{
            ColorColumns.RECORD_ID, ColorColumns.NAME, ColorColumns.R, ColorColumns.G,
            ColorColumns.B, ColorColumns.LAST_EDIT_STAMP};


    public static void createContractsTable(SQLiteDatabase db) {
        String contractsColumns = ColorColumns.NAME + " text DEFAULT (''),"
                + ColorColumns.R + " integer DEFAULT (0),"
                + ColorColumns.G + " integer DEFAULT (0),"
                + ColorColumns.B + " integer DEFAULT (0),"
                + ColorColumns.LAST_EDIT_STAMP + " long)";
        String createString = "(" + ColorColumns.RECORD_ID
                + " integer primary key autoincrement," + contractsColumns;
        db.execSQL("create table " + TABLE_NAME + createString);
    }

}
