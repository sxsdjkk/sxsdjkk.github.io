package com.alex.training.constant;

/**
 * Created by work on 15/11/12.
 */
public interface SaveType {

    int Local = 1;
    int File = 2;
    int Sqlite = 3;
}
