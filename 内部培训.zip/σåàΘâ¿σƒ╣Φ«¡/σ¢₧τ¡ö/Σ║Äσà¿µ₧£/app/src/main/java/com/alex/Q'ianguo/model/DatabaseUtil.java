package com.alex.training.model;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.alex.training.application.TrainingApplication;

/**
 *
 */
public class DatabaseUtil {

    private static final String TAG = DatabaseUtil.class.getSimpleName();

    private final static int DATABASE_VERSION = 1;

    private final static String DATABASE_NAME = "training";

    private DatabaseHelper DBHelper;
    static Context mContext;

    public static void init() {
        mContext = TrainingApplication.appContext;
        getInstance();
    }

    private DatabaseUtil(Context context, String databaseName) {
        mContext = context;
        DBHelper = new DatabaseHelper(context, databaseName);
    }

    private static class DatabaseUtilHolder {
        static DatabaseUtil INSTANCE = new DatabaseUtil(mContext, DATABASE_NAME);
    }

    public static DatabaseUtil getInstance() {
        if (mContext == null) {
            mContext = TrainingApplication.appContext;
        }
        return DatabaseUtilHolder.INSTANCE;
    }

    private class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper(Context context, String name) {
            super(context, name, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            ColorDBHelper.createContractsTable(db);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    }


    public SQLiteDatabase getReadableDatabase() {
        if (DBHelper == null) {
            DBHelper = new DatabaseHelper(mContext, DATABASE_NAME);
        }
        return DBHelper.getReadableDatabase();
    }

    public SQLiteDatabase getWritableDatabase() {
        if (DBHelper == null) {
            DBHelper = new DatabaseHelper(mContext, DATABASE_NAME);
        }
        return DBHelper.getWritableDatabase();
    }


    public static synchronized long insert(String table, ContentValues cv) {
        try {
            SQLiteDatabase db = getInstance().getWritableDatabase();
            return db.insert(table, null, cv);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        return 0L;
    }

    public static synchronized Cursor query(String table, String[] columns, String selection,
                                            String[] selectionArgs, String orderBy, String limit) {
        Log.d(TAG, "query " + table + " selection " + selection);
        Cursor cursor = null;
        try {
            SQLiteDatabase db = getInstance().getReadableDatabase();
            cursor = db.query(table, columns, selection, selectionArgs, null, null, orderBy, limit);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        return cursor;
    }

    /**
     * 更新数据库数据
     *
     * @param table       表名
     * @param values      需要更新的字段 和 对应的的数值
     * @param whereClause 约束条件
     * @param whereArgs   约束条件对应的数值
     * @return 影响的行数
     */
    public static synchronized int update(String table, ContentValues values,
                                          String whereClause, String[] whereArgs) {
        Log.d(TAG, "update " + table);
        try {
            SQLiteDatabase db = getInstance().getWritableDatabase();
            return db.update(table, values, whereClause, whereArgs);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        return 0;
    }

    /**
     * 删除数据
     *
     * @param table       表名
     * @param whereClause 条件
     * @param whereArgs   条件中对应的值
     * @return 被删除的行数
     */
    public static synchronized int delete(String table, String whereClause, String[] whereArgs) {
        Log.d(TAG, "delete " + table);
        try {
            SQLiteDatabase db = getInstance().getWritableDatabase();
            return db.delete(table, whereClause, whereArgs);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        return 0;
    }

    /**
     * 执行sql语句
     *
     * @param str sql语句
     */
    public static synchronized void exec(String str) {
        Log.d(TAG, "exec " + str);
        try {
            SQLiteDatabase db = getInstance().getWritableDatabase();
            db.execSQL(str);
        } catch (SQLException e) {
            Log.e(TAG, e.getMessage());
        }
    }

    // 获取某个数据库的表的名称
    public static boolean isExsitsTable(String tableName) {
        boolean result = false;
        Log.d(TAG, "isExsitsTable " + tableName);
        try {
            Cursor c = getInstance().getReadableDatabase()
                    .rawQuery("select name from sqlite_master where type='table' and name=?", new String[]{tableName});
            if (c != null) {
                if (c.moveToNext()) {
                    result = true;
                }
                c.close();
            }
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
        return result;
    }


    /**
     * 创建索引
     *
     * @param indexColumns 需要增加索引的列
     */
    public static synchronized void createIndex(SQLiteDatabase db, String[] indexColumns, String tableName) {
        Log.d(TAG, "createIndex " + tableName);
        if (db == null) {
            return;
        }
        for (String indexColumn : indexColumns) {
            String sql = "create index IF NOT EXISTS " + tableName.toLowerCase() + "_" + indexColumn.toLowerCase()
                    + " on " + tableName + "(" + indexColumn + ");";
            db.execSQL(sql);
        }
    }
}
