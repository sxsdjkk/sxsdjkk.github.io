package com.alex.training.application;

import android.app.Application;

import com.alex.training.model.DatabaseUtil;

public class TrainingApplication extends Application {

    public static TrainingApplication appContext;
    @Override
    public void onCreate() {
        super.onCreate();
        appContext = this;
        DatabaseUtil.init();
    }

}
