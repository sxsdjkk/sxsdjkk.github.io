package com.alex.training.model;

import android.text.TextUtils;

import java.io.Serializable;

public class Color implements Serializable, Comparable<Color> {

    private long _id = -1;
    private String name;
    private long last_edit_stamp;
    private int r;
    private int g;
    private int b;

    public String getColorString() {
        return _id + ";" + name + ";" + r + ";" + g + ";" + b + ";" + last_edit_stamp;
    }

    public static Color stringToColor(String colorStr) {
        if (TextUtils.isEmpty(colorStr)) {
            return null;
        }
        Color color = new Color();
        try {
            String[] strs = colorStr.split(";");
            color.set_id(Integer.valueOf(strs[0].trim()));
            color.setName(strs[1]);
            color.setR(Integer.valueOf(strs[2]));
            color.setG(Integer.valueOf(strs[3]));
            color.setB(Integer.valueOf(strs[4]));
            color.setLast_edit_stamp(Long.valueOf(strs[5]));
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return color;
    }

    public long get_id() {
        return _id;
    }

    public void set_id(long _id) {
        this._id = _id;
    }

    public int getColor() {
        return android.graphics.Color.rgb(r, g, b);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public long getLast_edit_stamp() {
        return last_edit_stamp;
    }

    public void setLast_edit_stamp(long last_edit_stamp) {
        this.last_edit_stamp = last_edit_stamp;
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    @Override
    public int compareTo(Color another) {
        return (int) (another.last_edit_stamp - this.last_edit_stamp);
    }

    private static final long serialVersionUID = -2536147330487664705L;

}
