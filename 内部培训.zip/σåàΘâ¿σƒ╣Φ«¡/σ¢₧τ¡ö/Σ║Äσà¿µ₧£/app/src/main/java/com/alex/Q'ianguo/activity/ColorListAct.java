package com.alex.training.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.alex.training.R;
import com.alex.training.activity.base.BaseActivity;
import com.alex.training.constant.ExtraName;
import com.alex.training.model.Color;
import com.alex.training.model.ColorDao;

import java.util.ArrayList;
import java.util.Collections;

public class ColorListAct extends BaseActivity {

    private final ArrayList<Color> colors = new ArrayList<>();
    private ColorsAdapter colorsAdapater;

    private int save_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_list);

        setText(R.id.action_bar_title, R.string.colorList_title);
        setText(R.id.action_bar_rightBtn, R.string.colorList_top_rightbtn);

        Intent i = getIntent();
        ArrayList<Color> temps = (ArrayList<Color>) i.getSerializableExtra(ExtraName.Color_List);
        if (temps != null) {
            colors.addAll(temps);
            Collections.sort(colors);
        }
        save_type = i.getIntExtra(ExtraName.Save_Type, 0);

        initViews();
    }

    public static void startColorListAct(Context context, ArrayList<Color> colors, int save_type) {
        Intent intent = new Intent(context, ColorListAct.class);
        intent.putExtra(ExtraName.Save_Type, save_type);
        intent.putExtra(ExtraName.Color_List, colors);
        context.startActivity(intent);
    }


    private void initViews() {
        ListView lv_colors = (ListView) findViewById(R.id.lv_colors);
        colorsAdapater = new ColorsAdapter(mContext);
        lv_colors.setAdapter(colorsAdapater);
        lv_colors.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Color color = (Color) parent.getItemAtPosition(position);
                CreateColorAct.startCreateColorAct(mContext, color, save_type);
            }
        });

        lv_colors.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> parent, View view, final int position, long id) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);  //先得到构造器
                builder.setMessage("删除颜色?"); //设置内容
                builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Color color = (Color) parent.getItemAtPosition(position);
                        ColorDao.deleteColor(mContext, save_type, color);
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.show();
                return true;
            }
        });

        findViewById(R.id.action_bar_rightBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CreateColorAct.startCreateColorAct(mContext, null, save_type);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        colors.clear();
        colors.addAll(ColorDao.getColors(mContext, save_type));
        Collections.sort(colors);
        colorsAdapater.notifyDataSetChanged();
    }

    class ColorsAdapter extends BaseAdapter {
        private LayoutInflater mInflater;

        public ColorsAdapter(Context context) {
            mInflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return colors.size();
        }

        @Override
        public Color getItem(int position) {
            if (position >= colors.size()) {
                return null;
            }
            return colors.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder;
            if (convertView == null) {
                convertView = mInflater.inflate(R.layout.item_color, null);
                holder = ViewHolder.getViewHolder(convertView);
            } else {
                holder = (ViewHolder) convertView.getTag();
            }

            Color color = getItem(position);
            if (color != null) {
                holder.view_color_preview.setBackgroundColor(color.getColor());
                holder.tv_color_name.setText(color.getName());
                holder.tv_color_r.setText(mContext.getString(R.string.item_color_r, color.getR()));
                holder.tv_color_g.setText(mContext.getString(R.string.item_color_r, color.getG()));
                holder.tv_color_b.setText(mContext.getString(R.string.item_color_r, color.getB()));
            } else {
                holder.view_color_preview.setBackgroundColor(0);
                holder.tv_color_name.setText("");
                holder.tv_color_r.setText(mContext.getString(R.string.item_color_r, 0));
                holder.tv_color_g.setText(mContext.getString(R.string.item_color_r, 0));
                holder.tv_color_b.setText(mContext.getString(R.string.item_color_r, 0));
            }

            return convertView;
        }


    }

    static class ViewHolder {
        TextView tv_color_name;
        TextView tv_color_r;
        TextView tv_color_g;
        TextView tv_color_b;
        View view_color_preview;

        public static ViewHolder getViewHolder(View convertView) {
            ViewHolder holder = new ViewHolder();
            holder.tv_color_name = (TextView) convertView.findViewById(R.id.tv_color_name);
            holder.tv_color_r = (TextView) convertView.findViewById(R.id.tv_color_r);
            holder.tv_color_g = (TextView) convertView.findViewById(R.id.tv_color_g);
            holder.tv_color_b = (TextView) convertView.findViewById(R.id.tv_color_b);
            holder.view_color_preview = convertView.findViewById(R.id.view_color_preview);
            convertView.setTag(holder);
            return holder;
        }
    }

}
