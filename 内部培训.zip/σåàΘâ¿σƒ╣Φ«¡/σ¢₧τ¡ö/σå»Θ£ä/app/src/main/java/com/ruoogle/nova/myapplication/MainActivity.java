package com.ruoogle.nova.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.ruoogle.nova.myapplication.util.DatabaseUtil;
import com.ruoogle.nova.myapplication.util.IntentExtra;
import com.ruoogle.nova.myapplication.data.SaveMode;

public class MainActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DatabaseUtil.init(this);
        setListensers();
    }


    private void setListensers() {
        findViewById(R.id.tv_local).setOnClickListener(this);
        findViewById(R.id.tv_file).setOnClickListener(this);
        findViewById(R.id.tv_database).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.tv_local:
                goList(SaveMode.LOCAL);
                break;
            case R.id.tv_file:
                goList(SaveMode.FILE);
                break;
            case R.id.tv_database:
                goList(SaveMode.DATABASE);
                break;
            default:
                break;
        }
    }

    private void goList(int saveMode) {
        Intent intent = new Intent(MainActivity.this, MainListActivity.class);
        intent.putExtra(IntentExtra.SaveMode, saveMode);
        startActivity(intent);
    }
}
