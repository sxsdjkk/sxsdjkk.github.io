package com.ruoogle.nova.myapplication.util;

import android.app.Activity;

import com.ruoogle.nova.myapplication.data.MyColor;

import org.apache.http.util.EncodingUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 文件操作
 * Created by fengxiao on 15/11/12.
 */
public class FileUtil {

    private static final String fileName = "color.txt";

    // 写入文件颜色
    public static void writeFile(Activity activity, List<MyColor> colorList) {
        File file = new File(activity.getFilesDir(), fileName);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            FileOutputStream color_outStream = new FileOutputStream(file);
            for (MyColor myColor : colorList) {
                color_outStream.write((myColor.name + ",").getBytes());
                color_outStream.write((myColor.R.toString() + ",").getBytes());
                color_outStream.write((myColor.G.toString() + ",").getBytes());
                color_outStream.write((myColor.B.toString() + ";").getBytes());
            }
            color_outStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 读取文件颜色
    public static List<MyColor> readFile(Activity activity) {
        List<MyColor> colorList = new ArrayList<>();
        try {
            FileInputStream color_inputStream = new FileInputStream(activity.getFilesDir()
                    + "/" + fileName);
            int length = color_inputStream.available();
            byte[] buffer = new byte[length];
            color_inputStream.read(buffer);
            String res = EncodingUtils.getString(buffer, "UTF-8");
            String[] colors = res.split(";");
            for (String color : colors) {
                String[] mColor = color.split(",");
                if (mColor.length == 4) {
                    MyColor myColor = new MyColor();
                    myColor.name = mColor[0];
                    myColor.R = Integer.valueOf(mColor[1]);
                    myColor.G = Integer.valueOf(mColor[2]);
                    myColor.B = Integer.valueOf(mColor[3]);
                    colorList.add(myColor);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return colorList;
    }
}
