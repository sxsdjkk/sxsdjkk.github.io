package com.ruoogle.nova.myapplication.util;

/**
 *
 * Created by fengxiao on 15/11/12.
 */
public class IntentExtra {

    public static final String SaveMode = "SaveMode";
    public static final String MyColor = "MyColor";
    public static final String Index = "Index";
}
