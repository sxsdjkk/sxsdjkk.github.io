package com.ruoogle.nova.myapplication.data;

/**
 * 存储模式
 * Created by fengxiao on 15/11/12.
 */
public class SaveMode {
    public static final int LOCAL = 1;
    public static final int FILE = 2;
    public static final int DATABASE = 3;
}
