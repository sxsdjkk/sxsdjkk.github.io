package com.ruoogle.nova.myapplication.data;

import java.io.Serializable;

/**
 *
 * Created by fengxiao on 15/11/12.
 */
public class MyColor implements Serializable {

    private static final long serialVersionUID = 1L;
    public Integer id;
    public String name;
    public Integer R;
    public Integer G;
    public Integer B;

}
