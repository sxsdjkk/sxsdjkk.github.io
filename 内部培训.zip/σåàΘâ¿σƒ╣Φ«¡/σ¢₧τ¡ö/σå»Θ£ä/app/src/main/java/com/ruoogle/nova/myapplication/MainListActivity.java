package com.ruoogle.nova.myapplication;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.ruoogle.nova.myapplication.data.MyColor;
import com.ruoogle.nova.myapplication.util.DatabaseUtil;
import com.ruoogle.nova.myapplication.util.FileUtil;
import com.ruoogle.nova.myapplication.util.IntentExtra;
import com.ruoogle.nova.myapplication.util.LocalStore;
import com.ruoogle.nova.myapplication.data.SaveMode;

import java.util.List;

public class MainListActivity extends Activity {

    private int saveMode;

    ListView lv_colors;
    private List<MyColor> colorList;
    private ColorAdapter colorAdapter;

    private static final int requestColorCreate = 1;
    private static final int requestColorChange = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_list);
        saveMode = getIntent().getIntExtra(IntentExtra.SaveMode, SaveMode.LOCAL);
        initView();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        switch (requestCode) {
            case requestColorCreate:
                if (resultCode == RESULT_OK) {
                    MyColor myColor = (MyColor) intent.getSerializableExtra(IntentExtra.MyColor);
                    colorList.add(0, myColor);
                    mHandler.sendEmptyMessage(UPDATE_VIEW);
                    if (saveMode == SaveMode.DATABASE) {
                        DatabaseUtil.insertColor(myColor);
                    }
                }
                break;
            case requestColorChange:
                if (resultCode == RESULT_OK) {
                    MyColor myColor = (MyColor) intent.getSerializableExtra(IntentExtra.MyColor);
                    int index = intent.getIntExtra(IntentExtra.Index, -1);
                    if (index >= 0) {
                        colorList.remove(index);
                        colorList.add(0, myColor);
                        mHandler.sendEmptyMessage(UPDATE_VIEW);
                    }
                    if (saveMode == SaveMode.DATABASE) {
                        DatabaseUtil.updateColor(myColor);
                    }
                }
                break;
            default:
                break;
        }
    }

    private void initView() {

        ((TextView) findViewById(R.id.tv_title)).setText(R.string.color_list);
        ((TextView) findViewById(R.id.tv_right)).setText(R.string.create);
        lv_colors = (ListView) findViewById(R.id.lv_colors);

        // setListeners
        findViewById(R.id.tv_right).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainListActivity.this, ColorDetailActivity.class);
                startActivityForResult(intent, requestColorCreate);
            }
        });
        findViewById(R.id.tv_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        lv_colors.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainListActivity.this, ColorDetailActivity.class);
                intent.putExtra(IntentExtra.Index, position);
                Bundle bundle = new Bundle();
                bundle.putSerializable(IntentExtra.MyColor, colorList.get(position));
                intent.putExtras(bundle);
                startActivityForResult(intent, requestColorChange);
            }
        });
        lv_colors.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainListActivity.this);
                builder.setTitle("提示"); //设置标题
                builder.setMessage("确认删除?"); //设置内容
                builder.setIcon(R.mipmap.ic_launcher);//设置图标，图片id即可
                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (saveMode == SaveMode.DATABASE) {
                            DatabaseUtil.deleteColor(colorList.get(position));
                        }
                        colorList.remove(position);
                        mHandler.sendEmptyMessage(UPDATE_VIEW);
                        dialog.dismiss();
                    }
                });
                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.create().show();
                return true;
            }
        });

        //getData
        colorAdapter = new ColorAdapter();
        switch (saveMode) {
            case SaveMode.LOCAL:
                // 本地缓存
                colorList = LocalStore.getColors(MainListActivity.this);
                break;
            case SaveMode.DATABASE:
                // 数据库
                colorList = DatabaseUtil.queryColors();
                break;
            case SaveMode.FILE:
                // 文件
                colorList = FileUtil.readFile(this);
                break;
            default:
                break;
        }
        //初始化页面
        lv_colors.setAdapter(colorAdapter);
        if (colorList.size() == 0) {
            findViewById(R.id.tv_right).performClick();
            return;
        }
        mHandler.sendEmptyMessage(UPDATE_VIEW);

    }

    @Override
    public void finish() {
        switch (saveMode) {
            case SaveMode.LOCAL:
                LocalStore.saveColors(MainListActivity.this, colorList);
                break;
            case SaveMode.FILE:
                FileUtil.writeFile(this, colorList);
                break;
        }
        super.finish();
    }


    private final int UPDATE_VIEW = 1;
    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case UPDATE_VIEW:
                    if (colorAdapter != null) {
                        colorAdapter.notifyDataSetChanged();
                    }
                    break;
                default:
                    break;
            }
        }
    };

    private class ColorAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return colorList.size();
        }

        @Override
        public Object getItem(int position) {
            return colorList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder;
            if (convertView == null) {
                viewHolder = new ViewHolder();
                LayoutInflater inflater = LayoutInflater.from(MainListActivity.this);
                convertView = inflater.inflate(R.layout.color_list_item, null);
                viewHolder.tv_name = (TextView) convertView
                        .findViewById(R.id.tv_name);
                viewHolder.v_bg = convertView.findViewById(R.id.v_bg);
                viewHolder.tv_r = (TextView) convertView
                        .findViewById(R.id.tv_r);
                viewHolder.tv_g = (TextView) convertView
                        .findViewById(R.id.tv_g);
                viewHolder.tv_b = (TextView) convertView
                        .findViewById(R.id.tv_b);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
            MyColor myColor = colorList.get(position);
            viewHolder.tv_name.setText(myColor.name);
            viewHolder.tv_r.setText("R:" + myColor.R);
            viewHolder.tv_g.setText("G:" + myColor.G);
            viewHolder.tv_b.setText("B:" + myColor.B);
            viewHolder.v_bg.setBackgroundColor(Color.argb(255, myColor.R, myColor.G, myColor.B));
            return convertView;
        }

        class ViewHolder {
            TextView tv_name;
            View v_bg;
            TextView tv_r;
            TextView tv_g;
            TextView tv_b;
        }
    }
}
