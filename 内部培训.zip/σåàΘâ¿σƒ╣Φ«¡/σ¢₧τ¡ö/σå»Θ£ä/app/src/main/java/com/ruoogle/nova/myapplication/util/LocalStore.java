package com.ruoogle.nova.myapplication.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.ruoogle.nova.myapplication.data.MyColor;

import java.util.ArrayList;
import java.util.List;

/**
 * 本地缓存
 * Created by fengxiao on 15/11/12.
 */
public class LocalStore {

    private static final String PACK_NAME = LocalStore.class.getPackage().getName();

    private static final String ColorList = "colorList";
    private static final String ColorSize = "colorSize";

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(
                PACK_NAME, Context.MODE_PRIVATE);
    }

    private static boolean saveArray(Context context, List<String> sKey) {
        SharedPreferences sharedPreferences = getSharedPreferences(context);
        SharedPreferences.Editor mEdit1 = sharedPreferences.edit();
        mEdit1.putInt(ColorSize, sKey.size());

        for (int i = 0; i < sKey.size(); i++) {
            mEdit1.remove(ColorList + i);
            mEdit1.putString(ColorList + i, sKey.get(i));
        }

        return mEdit1.commit();
    }

    private static List<String> loadArray(Context context) {
        SharedPreferences sharedPreferences = getSharedPreferences(context);
        List<String> mColors = new ArrayList<>();
        int size = sharedPreferences.getInt(ColorSize, 0);

        for (int i = 0; i < size; i++) {
            mColors.add(sharedPreferences.getString(ColorList + i, null));

        }
        return mColors;
    }


    public static void saveColors(Context context, List<MyColor> myColors) {
        List<String> mColors = new ArrayList<>();
        for (MyColor myColor : myColors) {
            String mColor = myColor.name + "," + myColor.R + "," + myColor.G + "," + myColor.B;
            mColors.add(mColor);
        }
        saveArray(context, mColors);
    }

    public static List<MyColor> getColors(Context context) {
        List<MyColor> myColorList = new ArrayList<>();
        List<String> mColors = loadArray(context);
        for (String sColor : mColors) {
            String[] color = sColor.split(",");
            if (color.length == 4) {
                MyColor myColor = new MyColor();
                myColor.name = color[0];
                myColor.R = Integer.valueOf(color[1]);
                myColor.G = Integer.valueOf(color[2]);
                myColor.B = Integer.valueOf(color[3]);
                myColorList.add(myColor);
            }
        }
        return myColorList;
    }
}
