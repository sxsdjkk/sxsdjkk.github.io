package com.ruoogle.nova.myapplication.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.ruoogle.nova.myapplication.data.MyColor;

import java.util.ArrayList;
import java.util.List;

/**
 * 数据库util
 * Created by fengxiao on 15/11/12.
 */
public class DatabaseUtil {


    private static SQLiteDatabase db;

    public static void init(Context context) {
        DatabaseHelper DBHelper = new DatabaseHelper(context);
        db = DBHelper.getReadableDatabase();
    }

    public static class DatabaseHelper extends SQLiteOpenHelper {

        private static final String DB_NAME = "mydata.db"; //数据库名称
        private static final int version = 1;              //数据库版本

        public DatabaseHelper(Context context) {
            super(context, DB_NAME, null, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String sql =
                    "create table color(id integer primary key autoincrement, name varchar(20) not null, r integer default 0 , g integer default 0 , b integer default 0, t long default 0);";
            db.execSQL(sql);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }

    }

    // 插入颜色
    public static void insertColor(MyColor myColor) {
        ContentValues cv = new ContentValues();
        cv.put("name", myColor.name);
        cv.put("r", myColor.R);
        cv.put("g", myColor.G);
        cv.put("b", myColor.B);
        cv.put("t", System.currentTimeMillis());
        db.insert("color", null, cv);
    }

    // 删除颜色
    public static void deleteColor(MyColor myColor) {
        String whereClause = "id=?";
        String[] whereArgs = {myColor.id + ""};
        db.delete("color", whereClause, whereArgs);
    }

    // 更新颜色
    public static void updateColor(MyColor myColor) {
        ContentValues cv = new ContentValues();
        cv.put("name", myColor.name);
        cv.put("r", myColor.R);
        cv.put("g", myColor.G);
        cv.put("b", myColor.B);
        cv.put("t", System.currentTimeMillis());
        String whereClause = "id=?";
        String[] whereArgs = {myColor.id + ""};
        db.update("color", cv, whereClause, whereArgs);
    }

    // 获取颜色列表
    public static List<MyColor> queryColors() {
        List<MyColor> colorList = new ArrayList<>();
        Cursor c = db.query("color", null, null, null, null, null, "t DESC");
        if (c != null) {
            c.moveToPosition(-1);
            while (c.moveToNext()) {
                MyColor myColor = new MyColor();
                myColor.id = c.getInt(c.getColumnIndex("id"));
                myColor.name = c.getString(c.getColumnIndex("name"));
                myColor.R = c.getInt(c.getColumnIndex("r"));
                myColor.G = c.getInt(c.getColumnIndex("g"));
                myColor.B = c.getInt(c.getColumnIndex("b"));
                colorList.add(myColor);
            }
        }
        c.close();
        return colorList;
    }
}

