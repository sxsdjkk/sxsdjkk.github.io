package com.ruoogle.nova.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ruoogle.nova.myapplication.data.MyColor;
import com.ruoogle.nova.myapplication.util.IntentExtra;

public class ColorDetailActivity extends Activity implements View.OnClickListener {


    private SeekBar sb_r;
    private SeekBar sb_g;
    private SeekBar sb_b;
    private EditText et_name;
    private View v_bg;
    MyColor myColor;
    int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_detail);
        initView();
        initData();
    }


    private void initView() {
        sb_r = (SeekBar) findViewById(R.id.sb_r);
        sb_g = (SeekBar) findViewById(R.id.sb_g);
        sb_b = (SeekBar) findViewById(R.id.sb_b);
        et_name = (EditText) findViewById(R.id.et_name);
        v_bg = findViewById(R.id.v_bg);

        ((TextView) findViewById(R.id.tv_right)).setText(R.string.save);

        findViewById(R.id.tv_back).setOnClickListener(this);
        findViewById(R.id.tv_right).setOnClickListener(this);

        sb_r.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ((TextView) findViewById(R.id.tv_r_value)).setText(progress + "");
                int color = getColor(progress, sb_g.getProgress(), sb_b.getProgress());
                v_bg.setBackgroundColor(color);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                myColor.R = seekBar.getProgress();
            }
        });

        sb_g.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ((TextView) findViewById(R.id.tv_g_value)).setText(progress + "");
                int color = getColor(sb_r.getProgress(), progress, sb_b.getProgress());
                v_bg.setBackgroundColor(color);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                myColor.G = seekBar.getProgress();
            }
        });

        sb_b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ((TextView) findViewById(R.id.tv_b_value)).setText(progress + "");
                int color = getColor(sb_r.getProgress(), sb_g.getProgress(), progress);
                v_bg.setBackgroundColor(color);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                myColor.B = seekBar.getProgress();
            }
        });

    }

    private void initData() {
        myColor = (MyColor) getIntent().getSerializableExtra(IntentExtra.MyColor);
        index = getIntent().getIntExtra(IntentExtra.Index, -1);

        if (myColor != null) {
            // 编辑颜色
            et_name.setText(myColor.name);
            sb_r.setProgress(myColor.R);
            sb_g.setProgress(myColor.G);
            sb_b.setProgress(myColor.B);
            ((TextView) findViewById(R.id.tv_r_value)).setText(myColor.R + "");
            ((TextView) findViewById(R.id.tv_g_value)).setText(myColor.G + "");
            ((TextView) findViewById(R.id.tv_b_value)).setText(myColor.B + "");
            ((TextView) findViewById(R.id.tv_title)).setText(R.string.edit_color);
        } else {
            // 新建颜色
            myColor = new MyColor();
            myColor.R = 0;
            myColor.G = 0;
            myColor.B = 0;
            ((TextView) findViewById(R.id.tv_title)).setText(R.string.create_color);
        }

        int color = getColor(myColor.R, myColor.G, myColor.B);
        v_bg.setBackgroundColor(color);
    }


    private int getColor(int r, int g, int b) {
        return Color.argb(255, r, g, b);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.tv_back:
                finish();
                break;

            case R.id.tv_right:
                myColor.name = ((EditText) findViewById(R.id.et_name)).getText().toString();
                if (TextUtils.isEmpty(myColor.name)) {
                    Toast.makeText(ColorDetailActivity.this,
                            R.string.need_name, Toast.LENGTH_LONG).show();
                    return;
                }
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable(IntentExtra.MyColor, myColor);
                intent.putExtras(bundle);
                intent.putExtra(IntentExtra.Index, index);
                setResult(RESULT_OK, intent);
                finish();
                break;

            default:
                break;
        }
    }
}
