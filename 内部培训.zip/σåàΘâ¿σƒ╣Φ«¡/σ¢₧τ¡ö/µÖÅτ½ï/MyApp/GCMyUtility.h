//
//  GCMyUtility.h
//  MyApp
//
//  Created by user on 15/11/12.
//  Copyright © 2015年 user. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GCMyUtility : NSObject

+ (NSString*)strFromeDate:(NSDate*)date;

+ (NSDate*)dateFromeStr:(NSString*)str;

@end
