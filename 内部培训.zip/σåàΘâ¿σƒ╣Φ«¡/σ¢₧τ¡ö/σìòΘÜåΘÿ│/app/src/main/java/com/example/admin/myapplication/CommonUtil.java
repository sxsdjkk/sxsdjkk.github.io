package com.example.admin.myapplication;

import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by admin on 2015/11/12.
 */
public class CommonUtil {

    /**
     * @param index       存储方式
     * @param mContext    上下文
     * @param mColorModel 存储对象
     */
    public static void sava(int index,
                            Context mContext,
                            ColorModel mColorModel) {

        if (index == StoreWay.share.index) {
            ArrayList<ColorModel> modelArrayList = new ArrayList<>();
            String mJson = SharedPreferencesUtil.gets(mContext, SharedPreferencesUtil.Color_List, null);
            if (TextUtils.isEmpty(mJson)) {
                modelArrayList.add(mColorModel);
            } else {
                modelArrayList = JsonUtil.getListFomJson(mJson, ColorModel.class);
                modelArrayList.add(0, mColorModel);
            }
            SharedPreferencesUtil.puts(mContext,
                    SharedPreferencesUtil.Color_List,
                    JsonUtil.toJson(modelArrayList));
        } else if (index == StoreWay.file_txt.index) {
            ArrayList<ColorModel> modelArrayList = new ArrayList<>();
            String mJson =
                    FileUtil.readFile();
            if (TextUtils.isEmpty(mJson)) {
                modelArrayList.add(mColorModel);
            } else {
                modelArrayList = JsonUtil.getListFomJson(mJson, ColorModel.class);
                modelArrayList.add(0, mColorModel);
            }
            FileUtil.saveTxt(JsonUtil.toJson(modelArrayList), mContext);
        } else if (index == StoreWay.db.index) {
            MyDatabase.insertColorModel(mColorModel);
        }
        Toast.makeText(mContext, "存储成功啦!!!!!!", Toast.LENGTH_LONG).show();
    }

    public static void sava(int index,
                            Context mContext,
                            ArrayList<ColorModel> mColorModel,
                            ColorModel mModel) {

        if (index == StoreWay.share.index) {
            SharedPreferencesUtil.puts(mContext,
                    SharedPreferencesUtil.Color_List,
                    JsonUtil.toJson(mColorModel));
        } else if (index == StoreWay.file_txt.index) {
            FileUtil.saveTxt(JsonUtil.toJson(mColorModel), mContext);
        } else if (index == StoreWay.db.index) {
            MyDatabase.insertColorModel(mModel);
        }
        Toast.makeText(mContext, "修改成功啦!!!!!!", Toast.LENGTH_LONG).show();
    }

    public static ArrayList<ColorModel> getArrayList(int index,
                                                     Context mContext
    ) {
        ArrayList<ColorModel> modelArrayList = new ArrayList<>();
        if (index == StoreWay.share.index) {
            String mJson = SharedPreferencesUtil.gets(mContext, SharedPreferencesUtil.Color_List, null);
            if (!TextUtils.isEmpty(mJson))
                modelArrayList = JsonUtil.getListFomJson(mJson, ColorModel.class);
        } else if (index == StoreWay.file_txt.index) {
            String mJson = FileUtil.readFile();
            if (!TextUtils.isEmpty(mJson))
                modelArrayList = JsonUtil.getListFomJson(mJson, ColorModel.class);
        } else if (index == StoreWay.db.index) {

            modelArrayList = MyDatabase.getList();
        }
        return modelArrayList;
    }


}
