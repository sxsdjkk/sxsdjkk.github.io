package com.example.admin.myapplication;

import android.text.TextUtils;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

/**
 * Created by admin on 2015/11/12.
 */
public class JsonUtil {

    private static Gson gson = new Gson();

    public static String toJson(Object o) {
        return gson.toJson(o);
    }

    public static <T> T getObject(String json, Class<T> classOfT) {
        return gson.fromJson(json, classOfT);
    }


    public static <T> ArrayList<T> getListFomJson(String json, Class<T> classOfT) {
        ArrayList<T> list = new ArrayList<>();
        if (TextUtils.isEmpty(json)) {
            return list;
        }
        try {
            JSONArray jsonArray = new JSONArray(json);
            int length = jsonArray.length();
            for (int i = 0; i < length; i++) {
                list.add(JsonUtil.getObject(jsonArray.optString(i), classOfT));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }


}
