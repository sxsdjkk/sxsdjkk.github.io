package com.example.admin.myapplication;

/**
 * Created by admin on 2015/11/12.
 */
public enum StoreWay {

    share(0),
    file_txt(1),
    db(2);

    public int index;

    StoreWay(int index) {
        this.index = index;
    }

}
