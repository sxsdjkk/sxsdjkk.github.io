package com.example.admin.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by admin on 2015/11/12.
 */
public class ColorListAct extends Activity implements View.OnClickListener {

    private ListView color_list;
    private TextView title_back, title_center, title_right;

    private ArrayList<ColorModel> mlist = new ArrayList();

    private ColorListAdapter mColorListAdapter;

    private int index;
    private int position;

    public static final int Result_code_success = 0x01;

    public static void starAct(Activity mContext, ArrayList<ColorModel> mlist, int index) {
        Intent mIntent = new Intent();
        mIntent.setClass(mContext, ColorListAct.class);
        mIntent.putExtra(IntentExtra.Color_List, mlist);
        mIntent.putExtra(IntentExtra.StoreWay, index);
        mContext.startActivity(mIntent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_color);
        getColorListIntent();
        findView();
        setListener();
        initView();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mlist = CommonUtil.getArrayList(index, this);
        Collections.sort(mlist);
        mColorListAdapter.setColorList(mlist);
    }

    private void initView() {
        mColorListAdapter = new ColorListAdapter(mlist, this);
        color_list.setAdapter(mColorListAdapter);
    }

    private void getColorListIntent() {
        mlist = (ArrayList<ColorModel>) getIntent().getSerializableExtra(IntentExtra.Color_List);
        index = (int) getIntent().getSerializableExtra(IntentExtra.StoreWay);
    }

    private void setListener() {
        title_back.setOnClickListener(this);
        title_right.setOnClickListener(this);
        color_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                position = i;
                CreateColorAct.starAct(ColorListAct.this, mlist.get(i), index);

            }
        });

        color_list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                //// TODO: 2015/11/13
                return false;
            }
        });

    }

    private void findView() {
        color_list = (ListView) findViewById(R.id.color_list);
        title_back = (TextView) findViewById(R.id.title_back);
        title_center = (TextView) findViewById(R.id.title_center);
        title_right = (TextView) findViewById(R.id.title_right);
        title_center.setText("颜色列表");
        title_right.setText("创建");
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.title_back:
                finish();
                break;
            case R.id.title_right:
                CreateColorAct.starAct(this, index);
                break;
            default:
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CreateColorAct.Requset_code_editor
                && resultCode == Result_code_success) {
            //save
            mlist.remove(position);
            ColorModel mColorModel = (ColorModel) data.getSerializableExtra(IntentExtra.Color_Model);
            mlist.add(mColorModel);
            CommonUtil.sava(index, this, mlist, mColorModel);
            mColorListAdapter.setColorList(mlist);
        }

    }
}
