package com.example.admin.myapplication;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by admin on 2015/11/12.
 */
public class SharedPreferencesUtil {

    //键值对存储
    //路径/data/data/包名/share.xml

    public static final String Color_List = "Color_List";

    private static final String PACK_NAME = SharedPreferencesUtil.
            class.
            getPackage().
            getName();

    private static SharedPreferences getSharedPreferences(Context context) {
        return context.getSharedPreferences(
                PACK_NAME, Context.MODE_PRIVATE);
    }

    public static void puts(Context context, String key, String value) {
        getSharedPreferences(context).edit().putString(key, value).commit();
    }

    public static String gets(Context context, String key, String defVal) {
        return getSharedPreferences(context).getString(key, defVal);
    }

}
