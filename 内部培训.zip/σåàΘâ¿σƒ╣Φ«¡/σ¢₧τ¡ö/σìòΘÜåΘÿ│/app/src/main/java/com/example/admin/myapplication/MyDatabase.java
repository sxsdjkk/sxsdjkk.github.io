package com.example.admin.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import java.util.ArrayList;

/**
 * Created by admin on 2015/11/12.
 */
public class MyDatabase {

    public static MyDatabase instance;

    private final static int DATABASE_VERSION = 1;
    public static DatabaseHelper databaseHelper;

    private static Context context;
    private final static String DATABASE_NAME = "mydatabase.db";

    public static MyDatabase getInstance() {

        synchronized (MyDatabase.class) {
            if (instance == null) {
                instance = new MyDatabase();
            }
        }
        return instance;
    }

    public static void initDatabase(Context mContext) {
        getInstance();
        context = mContext;
        databaseHelper = new DatabaseHelper(mContext, DATABASE_NAME);
        getReadableDatabase();
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper(Context context, String databaseName) {
            super(context, databaseName, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            createNotificationTable(sqLiteDatabase);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        }
    }

    private static void createNotificationTable(SQLiteDatabase db) {

        String ColorModel_Columns = ColorTable.color_name
                + " text," + ColorTable.value_r
                + " text," + ColorTable.value_g
                + " text," + ColorTable.value_b
                + " text," + ColorTable.lastupdateTime
                + " integer)";
        String createString = "(" + ColorTable.RECORD_ID
                + " integer primary key autoincrement," + ColorModel_Columns;
        exec("create table " + ColorTable.TABLE_NAME
                + createString, db);
    }


    /**
     * 执行sql语句
     *
     * @param str sql语句
     */
    private static void exec(String str, SQLiteDatabase db) {
        try {
            db.execSQL(str);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static SQLiteDatabase getReadableDatabase() {
        if (databaseHelper == null) {
            databaseHelper = new DatabaseHelper(context, DATABASE_NAME);
        }
        return databaseHelper.getReadableDatabase();
    }

    public static SQLiteDatabase getWritableDatabase() {
        if (databaseHelper == null) {
            databaseHelper = new DatabaseHelper(context, DATABASE_NAME);
        }
        return databaseHelper.getWritableDatabase();
    }

    public static synchronized long insert(String table, ContentValues cv) {
        try {
            SQLiteDatabase db = getInstance().getWritableDatabase();
            return db.insert(table, null, cv);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0L;
    }

    interface ColorTable {
        String TABLE_NAME = "colormodel";
        //自增长主键
        String RECORD_ID = "_id";
        //字段名
        String color_name = "color_name";
        String value_r = "value_r";
        String value_g = "value_g";
        String value_b = "value_b";
        String lastupdateTime = "lastupdateTime";
    }

    public static final String[] tableColumn = new String[]{
            ColorTable.RECORD_ID,
            ColorTable.color_name,
            ColorTable.value_r,
            ColorTable.value_g,
            ColorTable.value_b,
            ColorTable.lastupdateTime
    };

    public static long insertColorModel(ColorModel mColorModel) {

        ContentValues values = new ContentValues();
        beanToValues(mColorModel, values);
        long result;
        if (mColorModel.getId() > 0 && hadExitByid(ColorTable.TABLE_NAME, mColorModel.getId(), tableColumn)) {
            result = update(ColorTable.TABLE_NAME, values, ColorTable.RECORD_ID + "=?",
                    new String[]{String.valueOf(mColorModel.getId())});
        } else {
            result = insert(ColorTable.TABLE_NAME, values);
        }
        return result;
    }

    public static ArrayList<ColorModel> getList() {
        ArrayList mlist = new ArrayList();
        Cursor cursor = null;
        try {
            cursor = query(ColorTable.TABLE_NAME, tableColumn,
                    ColorTable.RECORD_ID + ">0",
                    null, null, null);
            if (cursor != null) {
                cursor.moveToPosition(-1);
                while (cursor.moveToNext()) {
                    mlist.add(cursorToColorModel(cursor));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            if (cursor != null)
                cursor.close();
        }
        return mlist;
    }


    private static ColorModel cursorToColorModel(Cursor cursor) {
        ColorModel model = new ColorModel();
        model.setId(cursor.getInt(cursor.getColumnIndexOrThrow(ColorTable.RECORD_ID)));
        model.setValue_r(cursor.getString(cursor.getColumnIndexOrThrow(ColorTable.value_r)));
        model.setValue_g(cursor.getString(cursor.getColumnIndexOrThrow(ColorTable.value_g)));
        model.setValue_b(cursor.getString(cursor.getColumnIndexOrThrow(ColorTable.value_b)));
        model.setColor_name(cursor.getString(cursor.getColumnIndexOrThrow(ColorTable.color_name)));
        model.setLastupdateTime(cursor.getLong(cursor.getColumnIndexOrThrow(ColorTable.lastupdateTime)));
        return model;
    }

    private static boolean hadExitByid(String table, int id, String tableColumn[]) {
        Cursor cursor = null;
        try {
            cursor = query(table, tableColumn,
                    ColorTable.RECORD_ID + "=?", new String[]{String.valueOf(id)}, null, null);
            if (cursor != null && cursor.moveToNext()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cursor.close();

        }
        return false;
    }

    public static synchronized int update(String table, ContentValues values,
                                          String whereClause, String[] whereArgs) {
        try {
            SQLiteDatabase db = getInstance().getWritableDatabase();
            return db.update(table, values, whereClause, whereArgs);
        } catch (Exception e) {
        }
        return 0;
    }


    private static Cursor query(String table,
                                String[] columns,
                                String selection,
                                String[] selectionArgs,
                                String orderBy,
                                String limit) {

        android.database.Cursor cursor = null;
        try {
            SQLiteDatabase db = getInstance().getReadableDatabase();
            cursor = db.query(table, columns, selection, selectionArgs, null, null, orderBy, limit);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cursor;
    }

    public static void beanToValues(ColorModel mColorModel, ContentValues values) {

        if (!TextUtils.isEmpty(mColorModel.getColor_name()))

            values.put(MyDatabase.ColorTable.color_name, mColorModel.getColor_name());

        values.put(MyDatabase.ColorTable.value_r, mColorModel.getValue_r());

        values.put(MyDatabase.ColorTable.value_g, mColorModel.getValue_g());

        values.put(MyDatabase.ColorTable.value_b, mColorModel.getValue_b());

        values.put(MyDatabase.ColorTable.lastupdateTime, mColorModel.getLastupdateTime());
    }


}
