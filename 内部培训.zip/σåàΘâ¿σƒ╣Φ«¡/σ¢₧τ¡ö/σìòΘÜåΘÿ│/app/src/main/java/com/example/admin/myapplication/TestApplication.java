package com.example.admin.myapplication;

import android.app.Application;
import android.util.DisplayMetrics;

/**
 * Created by admin on 2015/11/12.
 */
public class TestApplication extends Application {

    public static int screenWidth; // 屏幕宽
    public static int screenHeight; // 屏幕高

    public static TestApplication context;

    @Override
    public void onCreate() {
        super.onCreate();
        DisplayMetrics dm;
        dm = getResources().getDisplayMetrics();
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels;
        context = this;
        MyDatabase.initDatabase(this);

    }
}
