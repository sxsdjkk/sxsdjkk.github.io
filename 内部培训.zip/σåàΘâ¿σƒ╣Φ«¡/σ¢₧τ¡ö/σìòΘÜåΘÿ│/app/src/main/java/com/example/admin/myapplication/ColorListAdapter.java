package com.example.admin.myapplication;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by admin on 2015/11/12.
 */
public class ColorListAdapter extends BaseAdapter {

    private ArrayList<ColorModel> colorList = new ArrayList();

    private LayoutInflater lf;

    public ColorListAdapter(ArrayList<ColorModel> colorList, Context mContext) {
        this.colorList = colorList;
        lf = LayoutInflater.from(mContext);
    }

    public void setColorList(ArrayList<ColorModel> colorList) {
        this.colorList = colorList;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return colorList.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int pos, View view, ViewGroup viewGroup) {
        ViewHolder mViewHolder;

        if (view == null) {
            mViewHolder = new ViewHolder();
            view = lf.inflate(R.layout.item_color_list, viewGroup, false);
            mViewHolder.color_name = (TextView) view.findViewById(R.id.color_name);
            mViewHolder.value_r = (TextView) view.findViewById(R.id.value_r);
            mViewHolder.value_g = (TextView) view.findViewById(R.id.value_g);
            mViewHolder.value_b = (TextView) view.findViewById(R.id.value_b);
            mViewHolder.color = view.findViewById(R.id.color);
            view.setTag(mViewHolder);
        } else {
            mViewHolder = (ViewHolder) view.getTag();
        }
        initView(mViewHolder, colorList.get(pos));

        return view;
    }

    private void initView(ViewHolder mViewHolder, ColorModel mColorModel) {

        if (!TextUtils.isEmpty(mColorModel.getColor_name())) {
            mViewHolder.color_name.setText(mColorModel.getColor_name());
        }

        mViewHolder.value_r.setText(mColorModel.getValue_r());

        mViewHolder.value_g.setText(mColorModel.getValue_g());

        mViewHolder.value_b.setText(mColorModel.getValue_b());

        mViewHolder.color.setBackgroundColor(Color.rgb(Integer.parseInt(mColorModel.getValue_r()),
                Integer.parseInt(mColorModel.getValue_g()),
                Integer.parseInt(mColorModel.getValue_b())));
    }

    class ViewHolder {

        public TextView color_name;
        public TextView value_r;
        public TextView value_g;
        public TextView value_b;
        public View color;

    }


}
