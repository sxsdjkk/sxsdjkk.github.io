package com.example.admin.myapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Created by admin on 2015/11/12.
 */
public class CreateColorAct extends Activity implements
        SeekBar.OnSeekBarChangeListener, View.OnClickListener {


    //创建颜色
    public static void starAct(Context mContext, int index) {
        Intent mIntent = new Intent();
        mIntent.setClass(mContext, CreateColorAct.class);
        mIntent.putExtra(IntentExtra.StoreWay, index);
        mContext.startActivity(mIntent);
    }

    //修改
    public static void starAct(Activity mContext, ColorModel color, int index) {
        Intent mIntent = new Intent();
        mIntent.setClass(mContext, CreateColorAct.class);
        mIntent.putExtra(IntentExtra.Color_Model, color);
        mIntent.putExtra(IntentExtra.StoreWay, index);
        mContext.startActivityForResult(mIntent, Requset_code_editor);
    }

    private RelativeLayout color_parent;
    private View color_create;
    private EditText color_name;
    private SeekBar seek_r, seek_g, seek_b;
    private TextView value_r, value_g, value_b;
    private TextView title_right, title_center, title_back;
    private ColorModel mColorModel;
    private int index; //存储类型
    public static final int Requset_code_editor = 0x01;
    private boolean iseditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creat_color);
        findView();
        getColorIntent();
        setListener();
    }

    private void setListener() {
        seek_r.setOnSeekBarChangeListener(this);
        seek_g.setOnSeekBarChangeListener(this);
        seek_b.setOnSeekBarChangeListener(this);
        title_back.setOnClickListener(this);
        title_right.setOnClickListener(this);
    }

    private void getColorIntent() {
        index = (int) getIntent().getSerializableExtra(IntentExtra.StoreWay);
        mColorModel = (ColorModel) getIntent().getSerializableExtra(IntentExtra.Color_Model);

        if (mColorModel != null) {
            title_center.setText("编辑颜色");
            iseditor = true;
            value_r.setText(mColorModel.getValue_r());
            value_g.setText(mColorModel.getValue_g());
            value_b.setText(mColorModel.getValue_b());

            seek_r.setProgress(Integer.parseInt(mColorModel.getValue_r()));
            seek_g.setProgress(Integer.parseInt(mColorModel.getValue_g()));
            seek_b.setProgress(Integer.parseInt(mColorModel.getValue_b()));

            color_create.setBackgroundColor(Color.rgb(getSeekValue(value_r), getSeekValue(value_g), getSeekValue(value_b)));
        }

    }


    private void findView() {
        color_parent = (RelativeLayout) findViewById(R.id.color_parent);
        color_create = findViewById(R.id.color_create);
        color_name = (EditText) findViewById(R.id.color_name);
        color_parent.setLayoutParams(new LinearLayout.LayoutParams(TestApplication.screenWidth, TestApplication.screenWidth));
        seek_r = (SeekBar) findViewById(R.id.seek_r);
        seek_g = (SeekBar) findViewById(R.id.seek_g);
        seek_b = (SeekBar) findViewById(R.id.seek_b);
        value_r = (TextView) findViewById(R.id.value_r);
        value_g = (TextView) findViewById(R.id.value_g);
        value_b = (TextView) findViewById(R.id.value_b);
        title_right = (TextView) findViewById(R.id.title_right);
        title_center = (TextView) findViewById(R.id.title_center);
        title_back = (TextView) findViewById(R.id.title_back);
        title_center.setText("创建新的颜色");
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

        switch (seekBar.getId()) {

            case R.id.seek_r:
                setSeekValue(i, value_r);
                break;
            case R.id.seek_g:
                setSeekValue(i, value_g);
                break;
            case R.id.seek_b:
                setSeekValue(i, value_b);
                break;
            default:
                break;
        }
        color_create.setBackgroundColor(Color.rgb(getSeekValue(value_r), getSeekValue(value_g), getSeekValue(value_b)));
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    private void setSeekValue(int value, TextView textView) {
        textView.setText(String.valueOf(value));
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.title_back:
                finish();
                break;
            case R.id.title_right:

                if (iseditor) {
                    //编辑颜色
                    mColorModel.setValue_r(value_r.getText().toString());
                    mColorModel.setValue_g(value_g.getText().toString());
                    mColorModel.setValue_b(value_b.getText().toString());
                    mColorModel.setLastupdateTime();
                    mColorModel.setColor_name(color_name.getText().toString());
                    Intent mIntent = new Intent();
                    mIntent.putExtra(IntentExtra.Color_Model, mColorModel);
                    setResult(ColorListAct.Result_code_success, mIntent);
                    finish();
                } else {
                    mColorModel = ColorModel.creatColorModel(color_name.getText().toString(),
                            value_r.getText().toString(),
                            value_g.getText().toString(),
                            value_b.getText().toString()
                    );
                    //创建颜色
                    CommonUtil.sava(index, this, mColorModel);
                }
                break;
            default:
                break;
        }

    }

    private int getSeekValue(TextView textView) {

        return
                TextUtils.
                        isEmpty(textView.getText().toString()) ? 0 :
                        Integer.parseInt(textView.getText().toString());

    }

}
