package com.example.admin.myapplication;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import java.io.Serializable;

/**
 * Created by admin on 2015/11/12.
 */
public class ColorModel implements Serializable, Comparable {

    private String color_name;
    private String value_r;
    private String value_g;
    private String value_b;
    private long lastupdateTime;
    private int id = -1;

    //// TODO: 2015/11/12
    //rgb封装为一个值todo


//    private int index; //存储类型

    public String getColor_name() {
        return color_name;
    }

    public void setColor_name(String color_name) {
        this.color_name = color_name;
    }

    public String getValue_r() {
        return value_r;
    }

    public void setValue_r(String value_r) {
        this.value_r = value_r;
    }

    public String getValue_g() {
        return value_g;
    }

    public void setValue_g(String value_g) {
        this.value_g = value_g;
    }

    public String getValue_b() {
        return value_b;
    }

    public void setValue_b(String value_b) {
        this.value_b = value_b;
    }

    public long getLastupdateTime() {
        return lastupdateTime;
    }

    public void setLastupdateTime(long lastupdateTime) {
        this.lastupdateTime = lastupdateTime;
    }

    public void setLastupdateTime() {
        this.lastupdateTime = System.currentTimeMillis();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int compareTo(Object o) {
        ColorModel model = (ColorModel) o;
        return this.getLastupdateTime() > model.getLastupdateTime() ? -1 : 1;
    }

    @Override
    public String toString() {
        return "ColorModel{" +
                "color_name='" + color_name + '\'' +
                ", value_r='" + value_r + '\'' +
                ", value_g='" + value_g + '\'' +
                ", value_b='" + value_b + '\'' +
                ", lastupdateTime=" + lastupdateTime +
                '}';
    }

    public static ColorModel creatColorModel(String color_name,
                                             @NonNull
                                             String value_r,
                                             @NonNull
                                             String value_g,
                                             @NonNull
                                             String value_b) {
        ColorModel mColorModel = new ColorModel();

        if (!TextUtils.isEmpty(color_name)) {
            mColorModel.setColor_name(color_name);
        }
        mColorModel.setValue_r(value_r);
        mColorModel.setValue_g(value_g);
        mColorModel.setValue_b(value_b);
        mColorModel.setLastupdateTime();
        return mColorModel;
    }

}
