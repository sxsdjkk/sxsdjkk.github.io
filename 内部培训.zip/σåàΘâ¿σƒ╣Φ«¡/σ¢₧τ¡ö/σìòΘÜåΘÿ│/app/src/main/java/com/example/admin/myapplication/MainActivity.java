package com.example.admin.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setListener();
    }

    private void setListener() {
        findViewById(R.id.item_1).setOnClickListener(this);
        findViewById(R.id.item_2).setOnClickListener(this);
        findViewById(R.id.item_3).setOnClickListener(this);
    }


    private ArrayList<ColorModel> color_list = new ArrayList();

    @Override
    public void onClick(View view) {
        color_list.clear();
        switch (view.getId()) {
            case R.id.item_1:
                starColorCreateorColorList(StoreWay.share.index);
                break;
            case R.id.item_2:
                starColorCreateorColorList(StoreWay.file_txt.index);
                break;
            case R.id.item_3:
                starColorCreateorColorList(StoreWay.db.index);
                break;
            default:
                break;
        }
    }

    private void starColorCreateorColorList(int index) {
        color_list = CommonUtil.getArrayList(index, this);
        if (color_list.size() > 0) {
            //列表页
            ColorListAct.starAct(this, color_list, index);
        } else {
            //创建颜色
            CreateColorAct.starAct(this, index);
        }
    }


}
