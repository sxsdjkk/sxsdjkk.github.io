package com.example.admin.myapplication;

/**
 * Created by admin on 2015/11/12.
 */
public class IntentExtra {


    //集中管理  意图
    public static final String Color_List = "Color_List";

    public static final String Color_Model = "Color_Model";

    public static final String StoreWay = "StoreWay";


}
